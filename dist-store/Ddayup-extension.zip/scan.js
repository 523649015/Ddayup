// =====================================================================
// scan.js — 素材采集核心（由 background.js importScripts 引入，与 SW 共享作用域）
//
// 仅依赖 SW 全局（importScripts 后可见）：
//   NETWORK_ASSETS / VIDEO_HOST_RE / POLL_TIMERS / HMDAO_MSG / chrome
//   extractFreshVideoUrl / readAllCapturesMAIN（MAIN 世界注入函数，由 background.js 定义，运行时引用）
// scanPage 是纯页面注入函数（经 chrome.scripting.executeScript 注入 ISOLATED 世界），
// 内部仅引用页面可访问的 window.HMDAO_MSG（由 content script 暴露）与 document / location。
// =====================================================================
/* global NETWORK_ASSETS, VIDEO_HOST_RE, POLL_TIMERS, HMDAO_MSG, extractFreshVideoUrl, readAllCapturesMAIN, forceYtBufferAndCapture */

// 当前扫描到的抖音/视频号目标 aweme_id，用于在 merge 时优先保留“当前播放/当前 modal”的视频。
let __hmdao_current_aweme_id = null;

// 视频平台 URL 归一化（用于去重）：移除签名/时间戳等查询参数，保留协议+主机+路径。
function normalizeVideoUrl(url) {
  try {
    if (!url || typeof url !== 'string') return url || '';
    const u = new URL(url);
    // 对抖音/新片场/YouTube/B站等播放页或 CDN 直链，签名参数不同导致同一视频被当成多条素材。
    const host = u.hostname.toLowerCase();
    const isPlatform = /douyin|iesdouyin|tiktok|bytedance|xinpianchang|youtube|youtu|bilibili|bilivideo|b23\.tv|youku|qq\.com|iqiyi|ixigua|sohu|tudou|kuaishou|acfun|haokan|baidu/i.test(host);
    if (!isPlatform) return url;
    // 保留路径，但移除查询参数和 hash（不同签名/清晰度参数的同一视频归一）
    return u.origin + u.pathname;
  } catch (_) { return url || ''; }
}

// 判断 playerUrl 是否包含明确视频 ID（如抖音 modal_id / 新片场 a12345），
// 只有含 ID 时才按 playerUrl 去重，避免信息流页把不同视频误合并。
function playerUrlHasVideoId(playerUrl) {
  return /modal_id=|\/a\d+|\/video\/\d+|\/x\/|\/av\d+/i.test(playerUrl || '');
}

// 同 key 下保留「信息更完整」的那条资产；若已知抖音/视频号当前 aweme_id，
// 优先保留匹配当前 modal/播放的视频，避免信息流预加载的其它视频被选中。
function preferAsset(a, b) {
  if (!b) return true;
  const score = (x) => {
    let s = 0;
    if (__hmdao_current_aweme_id && x.awemeId === __hmdao_current_aweme_id) s += 2000; // 当前目标视频
    if (x.matched) s += 500;          // RENDER_DATA 精确匹配的视频
    if (x.source === 'deep-parse') s += 100; // 深度解析结果优先于脚本抓取
    if (x.playerUrl) s += 100;        // 有平台播放页 → 可走 yt-dlp
    if (x.title && !/^stream-/i.test(x.title)) s += 50;
    if (x.coverUrl || x.cover) s += 30;
    if (x.width && x.height) s += 20;
    if (x.name && !/^stream-/i.test(x.name)) s += 10;
    return s;
  };
  return score(a) > score(b);
}

// 扫描单个标签页：深度直链解析（B：网络层捕获 + MAIN 世界直链 + YouTube 缓冲补全） + 页面 DOM 解析（A）。
// 合并去重后回写 NETWORK_ASSETS 并广播 SCAN_RESULT 给侧栏。
async function scanTab(tabId, opts = {}) {
  const deep = opts.deep !== false; // 默认深度：首扫跑各站直链主动解析（B），轮询走轻量
  let networkAssets = [];
  let ytPlay = [];
  __hmdao_current_aweme_id = null; // 每次扫描重置当前抖音/视频号目标 ID

  // ===== B站播放页：纯旁观模式（不干扰播放器，保声音）=====
  // 根因：此前 scanTab 在 B站播放页仍注入 scanPage(ISOLATED) + extractFreshVideoUrl(MAIN) +
  // scanApiVideoUrls(MAIN)。其中 extractFreshVideoUrl 在播放页读取 __INITIAL_STATE__ 并触发 WBI
  // playurl/nav 请求，scanPage 扫描到播放器 <video src=blob> 与首帧预览图 → 既干扰 SPA 播放器
  // （导致有画面无声音），又产出"asset/home/all/frame/v2/40"等伪素材、多条同一视频的卡片。
  // 修复：B站播放页【只】做两件事——
  //   1) extractVideoCovers（只读 videoData.pic，零副作用）拿封面；
  //   2) 合并网络层被动捕获的 bilivideo 直链（background 层 passive 捕获，绝不碰播放器），
  //      并去重为「单条」视频（最高画质视频轨），不再把音频流/不同 itag 当成多个素材。
  // 不跑 scanPage / extractFreshVideoUrl / scanApiVideoUrls，彻底避免声音与伪素材问题。
  let isBiliPlay = false;
  let biliPlayUrl = '';
  try {
    const tab = await chrome.tabs.get(tabId);
    const u = (tab && tab.url) || '';
    isBiliPlay = /bilibili\.com\/(video|blackboard\/.*play|festival)\//i.test(u) || /b23\.tv\//i.test(u);
    if (isBiliPlay) biliPlayUrl = u;
  } catch (_) {}


  // 读取 MAIN 世界被动捕获（YouTube/抖音/B站/通用音频/3D模型的真实直链）
  const readMainCaptures = async () => {
    try {
      const injected = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: readAllCapturesMAIN,
      });
      const mainRes = injected && injected[0] && injected[0].result;
      if (mainRes) {
        if (Array.isArray(mainRes.videoPlays)) networkAssets.push(...mainRes.videoPlays);
        if (Array.isArray(mainRes.audioPlays)) networkAssets.push(...mainRes.audioPlays);
        // ★修复：抖音 MAIN 世界已捕获的 CDN 直链（dyUrls）此前没回传 → 抖音视频采不到。
        // 这里并入 networkAssets，合并阶段按 type==='video' 智能保留（不再被 VIDEO_HOST_RE 误杀）。
        if (Array.isArray(mainRes.dyUrls)) networkAssets.push(...mainRes.dyUrls.map((u) => ({ url: u, type: 'video', source: 'douyin' })));
        // ★扩展（2026-08-01）：接口响应体视频直链（liblib 等动态视频站点）
        if (Array.isArray(mainRes.apiVideos)) networkAssets.push(...mainRes.apiVideos.map((u) => ({ url: u, type: 'video', source: 'api-video' })));
        // ★爱给视频多分辨率：用户已在源页切换过的画质版本，按 quality 保留为同一素材的候选 URL
        if (Array.isArray(mainRes.aigeiVideos)) {
          networkAssets.push(...mainRes.aigeiVideos.map((v) => ({ url: v.url, type: 'video', source: 'aigei', quality: v.quality || '', path: v.path || '' })));
        }
        if (Array.isArray(mainRes.ytPlay)) ytPlay.push(...mainRes.ytPlay);
      }
    } catch (e) {
      console.warn('[HMDAO][scan] readAllCapturesMAIN 注入失败（普通网页无 MAIN 捕获属正常）：', e && e.message);
    }
  };
  await readMainCaptures();

  const n = NETWORK_ASSETS[tabId] || [];
  const netAssets = n.filter((a) => a && /googlevideo\.com\/videoplayback/.test(a.url));
  if (netAssets.length) networkAssets.push(...netAssets.map((a) => ({ url: a.url, type: 'video', source: 'youtube' })));
  // ★B站真实视频流（bilivideo 裸流）：background 网络层已无条件识别为 video 并存入 NETWORK_ASSETS。
  // 此前此处只并入 googlevideo，把 bilivideo 漏掉 → B站素材永远进不了侧栏。
  // 现一并并入，下游（isBiliPlay 分支）按 itag 去重为单条最高画质视频轨。
  const biliNet = n.filter((a) => a && /bilivideo\.(com|cn|tv)\b/i.test(a.url));
  if (biliNet.length) networkAssets.push(...biliNet.map((a) => ({ url: a.url, type: 'video', source: a.source || 'bilibili-network' })));
  // ★断点修复（2026-08-01）：爱给等音效站的试听走 SoundManager.createSound({url}) → 浏览器发起真实 .mp3 HTTP 请求
  // → webRequest 捕获入 NETWORK_ASSETS[type:'audio']。但此处上面只挑 googlevideo/bilivideo 把音频资产
  // 整条漏掉 → 侧栏「音频 0 / 试听音效采不到」。改为：把 NETWORK_ASSETS 里所有 audio 类型（除 bilivideo 外）也并入。
  const audioNet = n.filter((a) => a && a.type === 'audio' && !/bilivideo\.(com|cn|tv)\b/i.test(a.url));
  if (audioNet.length) {
    networkAssets.push(...audioNet.map((a) => ({ url: a.url, type: 'audio', source: a.source || 'network' })));
    console.log('[HMDAO][scan] 网络层音频资产并入:', audioNet.length, '条');
  }

  // ★爱给视频多分辨率聚合（2026-08-01）：同一视频不同画质版本合并为单条素材，
  // 最新签名的 URL 作为主 asset.url，其余版本放入 asset.altUrls，下载面板可切换分辨率。
  // 注意：这里只聚合来自 MAIN 捕获的 aigeiVideos，NETWORK_ASSETS 里的同名视频也在后续去重中处理。
  try {
    const aigeiItems = networkAssets.filter((a) => a && a.source === 'aigei' && a.path);
    if (aigeiItems.length > 1) {
      const byPath = new Map();
      for (const item of aigeiItems) {
        if (!byPath.has(item.path)) byPath.set(item.path, []);
        byPath.get(item.path).push(item);
      }
      const merged = [];
      for (const items of byPath.values()) {
        items.sort((x, y) => (y.ts || 0) - (x.ts || 0));
        const main = { ...items[0] };
        main.altUrls = items.slice(1).map((v) => ({ url: v.url, quality: v.quality || '', source: 'aigei' }));
        merged.push(main);
      }
      networkAssets = networkAssets.filter((a) => !(a && a.source === 'aigei' && a.path));
      networkAssets.push(...merged);
      console.log('[HMDAO][scan] 爱给视频多分辨率聚合:', merged.length, '组，候选 URL 数', aigeiItems.length);
    }
  } catch (e) {
    console.warn('[HMDAO][scan] 爱给视频聚合失败:', e && e.message);
  }

  // 主动扫描时若 YouTube 直链为空，或抖音有 <video> 但 dyUrls 为空（用户无操作未播放），
  // 静音缓冲 1.5s 触发播放器发请求，让 MAIN 世界拦截器捕获真实直链（打开页即扫描也能采到）。
  // ★B站不自动缓冲：走「用户选择后再解析」策略，不无脑 play/pause 触碰播放器（保护浏览端运行状态），
  // 也不会自动解析出一堆未经验证的素材。
  const needBuffer = !isBiliPlay && ytPlay.length === 0 && (networkAssets.length === 0 || !networkAssets.some((a) => a.type === 'video'));
  if (needBuffer) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: forceYtBufferAndCapture,
      });
      // 缓冲后重新读取 MAIN 捕获（此时 dyUrls/ytPlay 已填充）
      await readMainCaptures();
    } catch (e) {
      console.warn('[HMDAO][scan] forceYtBufferAndCapture 注入失败：', e && e.message);
    }
  }

  let pageAssets = [];
  let deepVideoAssets = [];
  if (isBiliPlay) {
    // 纯旁观：B站播放页不跑任何会碰播放器的注入（scanPage / extractFreshVideoUrl）。
    console.log('[HMDAO][scan] B站播放页：进入纯旁观模式（跳过 scanPage / extractFreshVideoUrl，保声音）');
  } else {
    try {
      const res = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'ISOLATED',
        func: scanPage,
        args: [networkAssets],
      });
      pageAssets = (res && res[0] && res[0].result) || [];
      console.log('[HMDAO][scan] DOM 解析产出', pageAssets.length, '条素材（含图片/视频/音频/3D模型/下载链接）');
    } catch (e) {
      console.warn('[HMDAO][scan] scanPage 注入/执行失败（tab 未就绪或不可脚本化）：', e && e.message);
    }

    // ★P0 回归修复：扫描阶段必须跑深度直链解析（extractFreshVideoUrl）。
    // 重构前 scanTab 直接调用它产出视频；重构后该函数仅剩 REFRESH_FROM_PAGE（点击刷新）才触发，
    // 导致打开任意视频站页面、首扫/轮询都采不到视频（DOM 只读到 blob: MSE 源，无真实直链）。
    // 这里【始终】调用（首扫与轮询都跑）：它是视频站采集的唯一来源，不跑则视频永远缺失。
    // 成本可控——extractFreshVideoUrl 优先读页面已就绪的全局（__playinfo__/__INITIAL_STATE__/拦截捕获），
    // 不发请求；仅兜底 WBI playurl 才发一次 API，且 inject-main 已常态拦截播放器请求。
    if (typeof extractFreshVideoUrl === 'function') {
      try {
        const fr = await chrome.scripting.executeScript({
          target: { tabId },
          world: 'MAIN',
          func: extractFreshVideoUrl,
          args: ['', networkAssets],
        });
        const r = (fr && fr[0] && fr[0].result) || null;
        if (r) {
          if (typeof r === 'string') {
            deepVideoAssets.push({ url: r, type: 'video', source: 'deep-parse' });
          } else if (r && r.__dash) {
            // DASH 结构：视频轨 +（可选）音轨，分开入库以便预览/下载分别处理
            if (r.video) deepVideoAssets.push({ url: r.video, type: 'video', source: 'deep-parse-dash', referer: r.referer, dashAudio: r.audio || null });
            if (r.audio) deepVideoAssets.push({ url: r.audio, type: 'audio', source: 'deep-parse-dash-audio', referer: r.referer });
          } else if (r && r.__douyin) {
            // 抖音/视频号：返回完整元数据，便于侧栏识别当前 modal 视频
            deepVideoAssets.push({
              url: r.url,
              type: 'video',
              source: 'deep-parse',
              matched: r.matched,
              formats: r.formats,
              title: r.title || '',
              cover: r.cover || '',
              awemeId: r.awemeId,
              duration: r.duration,
            });
            if (r.awemeId) __hmdao_current_aweme_id = r.awemeId;
          }
        }
        console.log('[HMDAO][scan] 深度直链解析产出', deepVideoAssets.length, '条视频/音频');
      } catch (e) {
        console.warn('[HMDAO][scan] extractFreshVideoUrl 注入/执行失败：', e && e.message);
      }
    }
  }

  // ★视频封面采集（供侧栏卡片显示封面图，悬停再抽帧）：
  // 注入 MAIN 世界读页面全局封面（B站 videoData.pic / 抖音 aweme.cover / 通用 <video poster>），
  // 以「视频直链」为键回填给 deepVideoAssets，也让通用 <video poster> 回填到同页视频资产。
  // 注意：deepVideoAssets 的 url 是播放直链（bilivideo CDN 等），与 <video poster> 不是同一 URL，
  // 故 poster 仅做「同页首个视频资产」的兜底封面（优先用页面全局封面键匹配）。
  let coverMap = null;
  try {
    const cr = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: extractVideoCovers,
      args: [],
    });
    coverMap = (cr && cr[0] && cr[0].result) || null;
    if (coverMap && (coverMap.pageCovers && coverMap.pageCovers.length || coverMap.defaultCover || (coverMap.byKey && Object.keys(coverMap.byKey).length))) {
      // 收集本次合并后页面里所有「视频类型」资产（深链 + 网络层 + 平台），统一补封面。
      // 关键点：B站播放页因熔断 model-api-capture 导致 deepVideoAssets 为空，
      // 此时视频直链来自网络层 networkAssets（bilivideo CDN），封面来自页面 videoData.pic，
      // 二者 URL 不同，必须用「同页视频资产兜底」而非 byKey 精确匹配。
      const pageVideoAssets = [];
      if (Array.isArray(deepVideoAssets)) pageVideoAssets.push(...deepVideoAssets);
      if (Array.isArray(networkAssets)) pageVideoAssets.push(...networkAssets.filter((n) => n && n.type === 'video'));
      if (Array.isArray(ytPlay)) pageVideoAssets.push(...ytPlay.map((u) => ({ url: u, type: 'video' })));

      // 1) byKey 精确匹配（页面已显式给出 直链→封面 映射时优先）
      if (coverMap.byKey && Object.keys(coverMap.byKey).length) {
        pageVideoAssets.forEach((dv) => {
          if (!dv.cover) {
            const hit = coverMap.byKey[dv.url] || coverMap.byKey[dv.url && dv.url.split('?')[0]];
            if (hit) dv.cover = hit;
          }
        });
      }
      // 2) 兜底：同页仍无封面的视频资产，统一用页面默认封面（B站 pic / 抖音 cover）
      if (coverMap.defaultCover) {
        pageVideoAssets.forEach((d) => { if (!d.cover) d.cover = coverMap.defaultCover; });
      }
      // 3) 通用 <video poster>：回填给同页、且无封面的视频资产（按顺序逐条分配）
      const posters = (coverMap.pageCovers || []).filter((c) => c.kind === 'poster');
      if (posters.length) {
        let pi = 0;
        pageVideoAssets.forEach((d) => {
          if (!d.cover && pi < posters.length) { d.cover = posters[pi].url; pi++; }
        });
      }
      // 把补好的封面同步回原始数组（networkAssets / deepVideoAssets），确保持久化与面板读取一致
      const syncCover = (arr) => {
        if (!Array.isArray(arr)) return;
        arr.forEach((d) => {
          const hit = pageVideoAssets.find((p) => p === d || (p.url && d.url && p.url.split('?')[0] === d.url.split('?')[0]));
          if (hit && hit.cover && !d.cover) d.cover = hit.cover;
        });
      };
      syncCover(deepVideoAssets);
      syncCover(networkAssets);
      console.log('[HMDAO][scan] 封面采集：byKey', coverMap.byKey ? Object.keys(coverMap.byKey).length : 0,
        'defaultCover', !!coverMap.defaultCover, 'posters', posters.length,
        'pageVideoAssets', pageVideoAssets.length);
    }
  } catch (e) {
    console.warn('[HMDAO][scan] extractVideoCovers 注入/执行失败（封面功能降级，不影响采集）：', e && e.message);
  }

  // ★修复：networkAssets（MAIN 世界抖音 dyUrls / 通用 audioPlays / 视频平台 videoPlays / 网络层捕获）
  // 此前只写进背景全局 NETWORK_ASSETS 持久化，却从未并入合并列表 → 抖音视频/音效永远采不到。
  // 现在与 ytPlay + pageAssets 一起进入合并（合并段按类型智能保留，不再被 VIDEO_HOST_RE 误杀）。
  let finalNetworkAssets = networkAssets;
  if (isBiliPlay) {
    // B站播放页：网络层会捕获多个 bilivideo 分片（音频流 / 视频流 / 不同 itag 清晰度）。
    // 这些其实是「同一个 B站视频」的多个流，必须去重为【单条】视频卡片，否则侧栏会出现
    // 多条「点击都是同一个视频」的素材。策略：只保留画质最高的「视频轨」（itag 最大），
    // 音频流(itag 较小或含 audio 标记)丢弃；封面由 extractVideoCovers 统一补。
    const bili = (networkAssets || []).filter((a) => a && a.type === 'video' && /bilivideo/i.test(a.url));
    // 非 B站视频流的网络资产（如页面里其它素材）始终保留
    const others = (networkAssets || []).filter((a) => !(a && a.type === 'video' && /bilivideo/i.test(a.url)));
    // ★封面回填：bilivideo 网络资产本身无 cover（background 只存 url/type/source），
    // 必须用 extractVideoCovers 采到的页面默认封面（B站 videoData.pic，原网无水印封面）回填，
    // 否则 B站视频卡片永远没封面。优先 defaultCover，其次 pageCovers[0]。
    const biliCover = (coverMap && coverMap.defaultCover) || (coverMap && coverMap.pageCovers && coverMap.pageCovers[0] && coverMap.pageCovers[0].url) || '';
    if (bili.length) {
      // 选「最高画质视频轨」：B站 bilivideo 分片含音频流(itag=30xxx)与视频流(itag<10000)，
      // 必须排除音频流（否则会选中 itag=30280 的音频而非视频）。策略：优先取 itag<10000 的视频流，取最大。
      const videoStreams = bili.filter((a) => {
        const it = Number((a.url.match(/itag[=_](\d+)/i) || [])[1] || 0);
        return it > 0 && it < 10000;
      });
      const pool = videoStreams.length ? videoStreams : bili;
      const pickHighest = pool.sort((x, y) => {
        const itx = Number((x.url.match(/itag[=_](\d+)/i) || [])[1] || 0);
        const ity = Number((y.url.match(/itag[=_](\d+)/i) || [])[1] || 0);
        return ity - itx;
      })[0];
      finalNetworkAssets = [...others, {
        url: pickHighest.url, type: 'video', source: 'bilibili',
        referer: 'https://www.bilibili.com', isBiliPlayAsset: true,
        platform: 'bilibili', biliPageUrl: biliPlayUrl,
        cover: biliCover,
      }];
      console.log('[HMDAO][scan] B站播放页 bilivideo 去重：', bili.length, '条分片 → 1 条（最高画质）');
    } else if (biliPlayUrl) {
      // ★2026-08-03：用户尚未播放、网络层无 bilivideo 被动捕获时，仍自动产出 B站视频资产，
      // url 用 B站页面地址（非过期裸流），让侧栏预览/下载时走 yt-dlp 真实解析（已实测可用：
      // BV1Wk3m6uEXG 返回 15 条 1080P~360P 格式）。全程不触碰源页播放器、不依赖播放动作。
      finalNetworkAssets = [...others, {
        url: biliPlayUrl, type: 'video', source: 'bilibili',
        referer: 'https://www.bilibili.com', isBiliPlayAsset: true,
        platform: 'bilibili', biliPageUrl: biliPlayUrl,
        cover: biliCover,
      }];
      console.log('[HMDAO][scan] B站播放页未捕获 bilivideo（用户未播放）→ 自动产出资产（url=页面地址，走 yt-dlp）');
    }
  }
  const all = [
    ...ytPlay.map((u) => ({ url: u, type: 'video', source: 'youtube' })),
    ...finalNetworkAssets,
    ...pageAssets,
    ...deepVideoAssets,
  ];
  // ★2026-08-02 增强去重：同一视频平台播放页/CDN 直链因签名参数不同会产生多条资产，
  // 旧逻辑按完整 URL 去重导致侧栏出现「多个相同视频」或「音频轨/视频轨」并存。
  // 新策略：
  //   1) 为抖音/新片场等资产补 playerUrl（平台播放页），供侧栏走 yt-dlp 统一解析；
  //   2) 按 playerUrl 归一去重；无 playerUrl 则按 normalizeVideoUrl(去查询参数) 归一；
  //   3) 同 key 保留信息更完整的资产（有标题/封面/平台页）。
  const dedupMap = new Map();
  const RES_EXT_RE = /\.(mp4|webm|mov|m4v|mkv|ogv|m3u8|flv|avi|wmv|ts|mpg|mpeg|3gp|rm|rmvb|asf|vob|m2ts|f4v|m4s|mp3|wav|ogg|aac|m4a|flac|opus|gif|apng|webp|png|jpe?g|bmp|svg|avif|ico|tiff?|glb|gltf|obj|fbx|stl|dae|ply|max|blend|ma|mb|c4d|3ds|skp|wrl|x3d|abc|lwo|smd|vrm)([?#]|$)/i;
  for (const a of all) {
    if (!a) continue;
    const u = (a.url || '').split('#')[0];
    if (!u) continue;
    // 图片：若 URL 带资源扩展名则保留；否则（裸页面导航 URL）丢弃
    if (a.type === 'image' && !RES_EXT_RE.test(u)) continue;
    // 媒体/模型/动图直链：无条件保留
    const isMediaOrModel = a.type === 'video' || a.type === 'audio' || a.type === 'model' || (a.animated === true);
    if (!isMediaOrModel && a.type !== 'image' && a.type !== 'archive' && a.type !== 'netdisk' && a.type !== 'link') continue;

    // 统一生成去重 key：
    // - playerUrl 含明确视频 ID（modal_id / a12345 等）时按 playerUrl 归一（解决同一视频多条签名直链）
    // - 否则按 normalizeVideoUrl（去签名参数）+ pageUrl 归一（避免信息流不同视频被误合并）
    let key;
    if (a.playerUrl && playerUrlHasVideoId(a.playerUrl)) {
      key = (a.playerUrl || '') + '|' + (a.type || 'video');
    } else {
      key = normalizeVideoUrl(u) + '|' + (a.type || 'video') + '|' + (a.pageUrl || '');
    }
    const existing = dedupMap.get(key);
    if (existing) {
      if (preferAsset(a, existing)) dedupMap.set(key, a);
      continue;
    }
    dedupMap.set(key, a);
  }
  const merged = Array.from(dedupMap.values());

  NETWORK_ASSETS[tabId] = merged;
  // ★P2（2026-08-01）：给每个资产补 tabId/pageUrl/playerUrl，供侧栏悬停试听/yt-dlp 解析使用。
  let srcPageUrl = '';
  let pageTitle = '';
  try {
    const t = await chrome.tabs.get(tabId);
    srcPageUrl = (t && t.url) || '';
    pageTitle = (t && t.title) || '';
  } catch (_) {}
  for (const a of merged) {
    if (!a) continue;
    a.tabId = tabId;
    if (!a.pageUrl) a.pageUrl = srcPageUrl;
    if (!a.title && pageTitle) a.title = pageTitle;
    if (!a.name && a.title) a.name = a.title;
    // 为抖音/新片场等资产补 playerUrl，让侧栏识别为 yt-dlp 平台并走统一解析
    if (!a.playerUrl && srcPageUrl) {
      if (/xinpianchang\.com\/a\d+/i.test(srcPageUrl)) {
        a.playerUrl = srcPageUrl;
      } else if (/(^|\.)douyin\.com/.test(srcPageUrl) || /(^|\.)iesdouyin\.com/.test(srcPageUrl)) {
        a.playerUrl = srcPageUrl;
      }
    }
  }
  // ★关键修复：侧栏加载时（bulk-actions.js）读取的持久化 key 是 'lastScan'，
  // 此前 scanTab 写的是 'hmdao_scan_${tabId}'，两套 key 不匹配 → 侧栏重启/重载后
  // 只能依赖 SCAN_RESULT 运行时广播；一旦广播因 SW 重启/侧栏加载时序竞态丢失，
  // 侧栏永远为空（真机「采不到」的头号根因）。统一写 'lastScan' 并供 storage.onChanged 实时接收。
  if (deep) {
    try { await chrome.storage.local.set({ lastScan: { assets: merged, tabId, ts: Date.now() } }); } catch (_) {}
  }

  // 扫描结果广播给侧栏（SCAN_RESULT 由 detect.js 转发到页面事件，侧栏监听）
  chrome.runtime.sendMessage({ type: HMDAO_MSG.SCAN_RESULT, tabId, assets: merged }).catch(() => {});
  return merged;
}

// 页面 DOM 解析（注入 ISOLATED 世界运行，禁止引用 background 作用域）。
// networkAssets: 由 background 透传的网络层捕获资产（含 source 字段，供侧栏/测试区分来源）。
function scanPage(networkAssets) {
  let out = [];
  const push = (url, type, source, meta) => {
    if (!url) return;
    // 动图检测：gif/apng/动图 webp 标记 animated，预览直显（不重编码），合并阶段据此免过滤
    let animated = false;
    if (type === 'image') {
      const lower = String(url).toLowerCase();
      if (/\.(gif|apng)(\?|$)/i.test(lower)) animated = true;
      else if (/format=apng|format=gif/i.test(lower)) animated = true;
    }
    let u = String(url).trim();
    if (!/^https?:\/\//i.test(u)) return;
    const item = { url: u, type, source };
    if (animated) item.animated = true;
    if (meta && typeof meta === 'object') Object.assign(item, meta);
    out.push(item);
  };

  // 1) 图片：<img src/currentSrc/srcset> + data-* 属性 + 内联 style background + <picture>
  document.querySelectorAll('img').forEach((img) => {
    const src = img.currentSrc || img.src;
    push(src, 'image', 'img');
    if (img.srcset) {
      img.srcset.split(',').forEach((s) => {
        const u = s.trim().split(/\s+/)[0];
        push(u, 'image', 'img[srcset]');
      });
    }
  });
  document.querySelectorAll('picture source').forEach((s) => push(s.srcset ? s.srcset.split(',')[0].trim().split(/\s+/)[0] : s.src, 'image', 'picture'));
  document.querySelectorAll('[style]').forEach((el) => {
    const st = el.getAttribute('style') || '';
    const m = st.match(/url\(['"]?(https?:\/\/[^'")]+)['"]?\)/i);
    if (m) push(m[1], 'image', 'css-bg');
  });
  document.querySelectorAll('[data-src], [data-original], [data-lazy], [data-bg], [data-image], [data-img], [data-url], [data-pic], [data-thumb], [data-preview]').forEach((el) => {
    ['data-src', 'data-original', 'data-lazy', 'data-bg', 'data-image', 'data-img', 'data-url', 'data-pic', 'data-thumb', 'data-preview'].forEach((k) => push(el.getAttribute(k), 'image', 'img[data]'));
  });
  document.querySelectorAll('a[href]').forEach((a) => {
    const href = a.getAttribute('href');
    if (/\.(jpe?g|png|gif|webp|bmp|svg|avif|ico|tiff?)([?#]|$)/i.test(href)) {
      const img = a.querySelector('img');
      if (img) push(img.currentSrc || img.src, 'image', 'a>img');
      else push(href, 'image', 'a>img');
    }
  });

  // 2) 视频：<video src> + <source> + poster + 属性 + 内联脚本/全局变量
  document.querySelectorAll('video').forEach((v) => {
    push(v.src, 'video', 'video');
    v.querySelectorAll('source').forEach((s) => push(s.src, 'video', 'video>source'));
    if (v.poster) push(v.poster, 'image', 'video[poster]');
  });
  document.querySelectorAll('[data-video], [data-src], [data-mp4], [data-video-src], [data-play]').forEach((el) => {
    ['data-video', 'data-src', 'data-mp4', 'data-video-src', 'data-play'].forEach((k) => push(el.getAttribute(k), 'video', 'video[attr]'));
  });
  // 2.5) 视频直链（含 m3u8 / 直播）：<a href="*.mp4"> 等 + 属性 + 脚本/全局变量
  const VID_RE = /\.(mp4|webm|mov|m4v|mkv|ogv|m3u8|flv|avi|wmv|ts|mpg|mpeg|3gp|rm|rmvb|asf|vob|m2ts|f4v|m4s)([?#]|$)/i;
  document.querySelectorAll('a[href]').forEach((a) => { if (VID_RE.test(a.href)) push(a.href, 'video', 'a[href]'); });
  document.querySelectorAll('*').forEach((el) => {
    el.getAttributeNames().forEach((name) => {
      const v = el.getAttribute(name);
      if (!v || typeof v !== 'string') return;
      const m = v.match(/https?:\/\/[^ "'()]+/i);
      if (m && VID_RE.test(m[0])) push(m[0], 'video', 'attr:' + name);
    });
  });
  document.querySelectorAll('script:not([src])').forEach((s) => {
    const urls = (s.textContent || '').match(/https?:\/\/[^ "'()]+(\.(mp4|webm|mov|m4v|mkv|ogv|m3u8|flv|avi|wmv|ts|mpg|mpeg|3gp|rm|rmvb|asf|vob|m2ts|f4v|m4s)|(\.(mp4|webm|mov|m4v|mkv|ogv|m3u8|flv|avi|wmv|ts|mpg|mpeg|3gp|rm|rmvb|asf|vob|m2ts|f4v|m4s)))([?#]|$)/ig) || [];
    urls.forEach((u) => push(u, 'video', 'script'));
  });
  try {
    ['videoList', 'videos', 'videoData', 'playerData', 'playList', 'playlist', 'videoInfo', 'mediaList', '__VIDEO__'].forEach((k) => {
      const obj = window[k];
      if (!obj) return;
      const urls = JSON.stringify(obj).match(/https?:\/\/[^ "'()]+/g) || [];
      urls.forEach((u) => { if (VID_RE.test(u)) push(u, 'video', 'global'); });
    });
  } catch (_) {}

  // 2.7) 嵌入视频平台 URL 扫描（让网页内嵌的 YouTube/B站/优酷/腾讯/iqiyi 等 走 yt-dlp 拿全清晰度）：
  // 网页里很多"带分辨率选项的视频"是这些平台播放器 iframe 嵌进来的，其真实视频直链是
  // googlevideo/bilivideo/cibntv 等防盗链地址（无法选清晰度、直连 403），但 iframe.src 里的平台 URL
  // 能被 yt-dlp 识别并枚举所有清晰度。本步提取规范化后的平台 URL 入库，供预览/下载走 yt-dlp。
  // ★扩展（2026-08-01）：原只识别 YouTube/B站，youku/tudou/腾讯/iqiyi 等国内嵌入被直接丢弃 →
  //   云桥网(yunqiaowang)等用 youku 嵌入的站点采不到。现扩到主流国内平台。
  const EMBED_SOURCES = [];
  const collectEmbedUrl = (raw) => { if (raw) EMBED_SOURCES.push(String(raw)); };
  // a) 直接 iframe（跨域 iframe 的 src 属性本身可读，仅内部 DOM 不可读）
  document.querySelectorAll('iframe').forEach((ifr) => {
    collectEmbedUrl(ifr.src);
    collectEmbedUrl(ifr.getAttribute('data-src'));
  });
  // b) 页面里的平台链接（<a href>、data-*、全局变量、内联脚本）
  document.querySelectorAll('a[href]').forEach((a) => collectEmbedUrl(a.href));
  ['data-video', 'data-src', 'data-url', 'data-href', 'data-link', 'data-embed'].forEach((k) => {
    document.querySelectorAll('[' + k + ']').forEach((el) => collectEmbedUrl(el.getAttribute(k)));
  });
  (function () {
    const txt = (document.documentElement && document.documentElement.innerHTML) || '';
    const m = txt.match(/https?:\/\/(www\.)?(youtube\.com\/(watch\?v=|embed\/|shorts\/)|youtu\.be\/|player\.bilibili\.com\/player\.html\?bvid=|www\.bilibili\.com\/video\/|player\.youku\.com\/embed\/|v\.youku\.com\/v_show\/|video\.tudou\.com\/[a-z]\/|v\.qq\.com\/[a-z]+\/|www\.iqiyi\.com\/[a-z0-9_]+\.html|www\.iqiyi\.com\/v_|ixigua\.com\/[0-9]+|www\.sohu\.com\/[a-z]+\/[0-9]+)[^\s"'<>()]+/gi) || [];
    m.forEach(collectEmbedUrl);
  })();
  // 规范化 + 入库。返回 { platform, playerUrl, ... } 或 null。
  // 设计：★先做「白名单特殊规范化」——YT/B站/youku/qq/iqiyi/tudou/西瓜/搜狐 等已知平台，
  // 解析出更干净稳定的播放页 playerUrl（去参数/统一域名），便于 yt-dlp 稳定提取。
  // ★白名单未命中，则做「通用兼容」回退：任何看起来像视频平台播放页的 URL
  // （含已知视频平台域名，或路径含 /embed/ /v_ /v_show/ /video/ 等视频特征）都按
  // generic 平台入库，直接以原始 raw URL 作为 playerUrl 交给 yt-dlp 尝试提取。
  // 这样「未列在白名单的小众/海外平台」也能被采集，特殊平台再走白名单做规范化增强。
  const VIDEO_PLATFORM_HOST_RE = /(youtube\.com|youtu\.be|bilibili\.com|youku\.com|tudou\.com|qq\.com|iqiyi\.com|ixigua\.com|sohu\.com|le\.com|acfun\.cn|1905\.com|mgtv\.com|v\.qq\.com|v\.ku6\.com|kankan\.com|56\.com|fun\.tv|pptv\.com|wasu\.cn|cntv\.cn|bokecc\.com|polyv\.net|qiyi\.com|v\.163\.com|open\.163\.com|vimeo\.com|dailymotion\.com|facebook\.com|twitter\.com|vk\.com|ok\.ru|rutube\.ru|streamable\.com|twitch\.tv|invidious\.|piped\.|peertube|mixcloud\.com|soundcloud\.com|ted\.com|metacafe\.com|break\.com|liveleak\.com|veoh\.com|9cache\.com|bits\.co|bitchute\.com|rumble\.com|odysee\.com|brighteon\.com|v\.douyin\.com|douyin\.com|kuaishou\.com|bilibili\.tv|nicovideo\.jp|dmm\.co\.jp|niconico)/i;
  const VIDEO_PATH_RE = /\/(embed|player|v_show|v_|video|watch|shorts|play|player\.html|v\/|detail|media|mv|live)\b/i;
  function normalizeEmbedPlatform(raw) {
    try {
      const u = new URL(raw, location.href);
      const h = u.hostname;
      // ===== 白名单特殊规范化（稳定 playerUrl / 视频 ID） =====
      // YouTube
      if (/(^|\.)youtube\.com$/.test(h)) {
        let videoId = null;
        if (u.pathname === '/watch') videoId = u.searchParams.get('v');
        else if (u.pathname.startsWith('/embed/')) videoId = u.pathname.split('/embed/')[1].split('/')[0];
        else if (u.pathname.startsWith('/shorts/')) videoId = u.pathname.split('/shorts/')[1].split('/')[0];
        if (videoId) return { platform: 'youtube', ytPageUrl: 'https://www.youtube.com/watch?v=' + videoId, ytVideoId: videoId };
      } else if (/(^|\.)youtu\.be$/.test(h)) {
        const videoId = u.pathname.slice(1).split('/')[0];
        if (videoId) return { platform: 'youtube', ytPageUrl: 'https://www.youtube.com/watch?v=' + videoId, ytVideoId: videoId };
      } else if (/(^|\.)bilibili\.com$/.test(h)) {
        let videoId = null;
        if (u.pathname.startsWith('/video/')) videoId = u.pathname.split('/video/')[1].split('/')[0];
        else if (u.pathname === '/player.html' || u.pathname === '/player/') videoId = u.searchParams.get('bvid');
        if (videoId && /^BV/.test(videoId)) return { platform: 'bilibili', biliPageUrl: 'https://www.bilibili.com/video/' + videoId, biliVideoId: videoId };
      } else if (/(^|\.)youku\.com$/.test(h)) {
        let vid = null;
        if (u.pathname.startsWith('/embed/')) vid = u.pathname.split('/embed/')[1].split('/')[0];
        else { const m = u.href.match(/id_([A-Za-z0-9]+)/); if (m) vid = m[1]; }
        // 必须转成 yt-dlp 能解析的 v_show 播放页；embed URL 不被 yt-dlp 支持。
        if (vid) return { platform: 'youku', playerUrl: 'https://v.youku.com/v_show/id_' + vid + '.html' };
      } else if (/(^|\.)tudou\.com$/.test(h)) {
        const m = u.href.match(/iid_([0-9]+)|code_([A-Za-z0-9]+)/);
        const vid = m && (m[1] || m[2]);
        if (vid) return { platform: 'tudou', playerUrl: raw };
      } else if (/(^|\.)qq\.com$/.test(h)) {
        const m = u.href.match(/\/([a-z]+)\/([A-Za-z0-9]+)/);
        if (m) return { platform: 'qq', playerUrl: raw };
      } else if (/(^|\.)iqiyi\.com$/.test(h)) {
        const m = u.href.match(/v_([A-Za-z0-9]+)/) || u.pathname.match(/\/([a-z0-9_]+)\.html/);
        if (m) return { platform: 'iqiyi', playerUrl: raw };
      } else if (/ixigua\.com$/.test(h)) {
        return { platform: 'xigua', playerUrl: raw };
      } else if (/(^|\.)sohu\.com$/.test(h)) {
        return { platform: 'sohu', playerUrl: raw };
      }
      // ===== 通用兼容回退（白名单未命中） =====
      // 已知视频平台域名，或路径含视频播放特征 → 按 generic 平台处理，以原始 URL 作为 playerUrl 交给 yt-dlp。
      if (VIDEO_PLATFORM_HOST_RE.test(h) || VIDEO_PATH_RE.test(u.pathname)) {
        if (h === 'null' || u.toString() === 'null') return null; // 拒绝字面量 "null" 入库
        return { platform: 'generic', playerUrl: u.toString() };
      }
    } catch (_) {}
    return null;
  }
  EMBED_SOURCES.forEach((raw) => {
    const info = normalizeEmbedPlatform(raw);
    if (info && info.platform && info.playerUrl) {
      // 以平台播放页 URL 作为 url，便于 isYtDlpPlatform 识别（yt-dlp 支持大量平台，含 generic）。
      const meta = Object.assign({ platform: info.platform }, info.playerUrl && info.playerUrl !== 'null' ? { playerUrl: info.playerUrl } : {});
      if (info.ytPageUrl && info.ytPageUrl !== 'null') meta.ytPageUrl = info.ytPageUrl;
      if (info.ytVideoId && info.ytVideoId !== 'null') meta.ytVideoId = info.ytVideoId;
      if (info.biliPageUrl && info.biliPageUrl !== 'null') meta.biliPageUrl = info.biliPageUrl;
      if (info.biliVideoId && info.biliVideoId !== 'null') meta.biliVideoId = info.biliVideoId;
      push(info.playerUrl, 'video', 'embed-platform', meta);
    }
  });

  // ★注意：接口响应体视频直链（LiblibAI / 模型社区等"视频在 XHR/fetch 响应里动态注入"的站点）
  // 不再在 ISOLATED 世界读 window.__hmdao_captures.apiVideos —— MAIN 世界变量在 ISOLATED 不可见。
  // 改为由 scanTab 经 readAllCapturesMAIN（world:'MAIN'）回读 apiVideos 并并入 networkAssets，
  // 见本文件 scanTab 的 readMainCaptures（source='api-video'）。

  // 3) 音频：<audio src> + <source> + data-* + 属性 + 内联脚本/全局变量 + 播放器配置
  const AUD_RE = /\.(mp3|wav|flac|ogg|aac|m4a|wma|opus)(\?[^"'\s}]*)?/i;
  document.querySelectorAll('audio').forEach((a) => {
    push(a.src, 'audio', 'audio');
    a.querySelectorAll('source').forEach((s) => push(s.src, 'audio', 'audio>source'));
  });
  document.querySelectorAll('[data-audio], [data-src], [data-mp3], [data-music], [data-song], [data-track]').forEach((el) => {
    ['data-audio', 'data-src', 'data-mp3', 'data-music', 'data-song', 'data-track'].forEach((k) => push(el.getAttribute(k), 'audio', 'audio[attr]'));
  });
  document.querySelectorAll('*').forEach((el) => {
    el.getAttributeNames().forEach((name) => {
      const v = el.getAttribute(name);
      if (!v || typeof v !== 'string') return;
      const m = v.match(/https?:\/\/[^ "'()]+/i);
      if (m && AUD_RE.test(m[0])) push(m[0], 'audio', 'attr:' + name);
    });
  });
  document.querySelectorAll('script:not([src])').forEach((s) => {
    const urls = (s.textContent || '').match(/https?:\/\/[^ "'()]+/ig) || [];
    urls.forEach((u) => { if (AUD_RE.test(u)) push(u, 'audio', 'script'); });
  });
  try {
    ['audioList', 'audios', 'musicList', 'songList', 'audioData', 'playerData', '__AUDIO__'].forEach((k) => {
      const obj = window[k];
      if (!obj) return;
      const urls = JSON.stringify(obj).match(/https?:\/\/[^ "'()]+/g) || [];
      urls.forEach((u) => { if (AUD_RE.test(u)) push(u, 'audio', 'global'); });
    });
  } catch (_) {}
  // 部分播放器把 playlist 序列化在 <div data-player-config='[...]'> 中
  document.querySelectorAll('[data-player-config]').forEach((el) => {
    try { const v = el.getAttribute('data-player-config'); if (v) {
      const re = /https?:\/\/[^"'\s}]+\.(mp3|wav|flac|ogg|aac|m4a|wma|opus)(\?[^"'\s}]*)?/gi;
      let m; while ((m = re.exec(v)) && out.length < 800) push(m[0], 'audio', 'player-config');
    }} catch (_) {}
  });

  // 3D 模型：覆盖 <model-viewer>/A-Frame/直链/<a href>/属性/内联脚本/全局变量/下载按钮等多种藏匿方式
  // ★根因 A 修复：锚点原写死 ([?]|#|$)，要求扩展名后紧跟 ?/#/结尾。
  // 但 3D 站下载链接常是 ?file=robot.fbx&sign=abc（扩展名后是 &），原正则不匹配 → 整类模型从未被识别。
  // 改为 ([?#&]|$)：扩展名后是 ?/#/&/结尾都算命中（& 仅在 ? 后出现才合法，这里放宽不影响判断，
  // 因为 .fbx 不会出现在随机文本里，误匹配风险极低）。
  const MODEL_RE = /[.](glb|gltf|obj|fbx|stl|usdz|max|blend|ma|mb|c4d|dae|ply|3ds|skp|wrl|x3d|abc|lwo|smd|vrm|ase|dxf|bvh)([?#&]|$)/i;
  const ARCH_RE = /[.](zip|rar|7z|tar[.]gz|tgz|tar[.]bz2|gz|bz2|tar|iso|cab|jar)([?#&]|$)/i;
  const URL_RE = new RegExp("https?://[^ \"'()]+", "gi");
  // 1) <model-viewer> / A-Frame <a-asset-item> / <a-scene> 的 src
  document.querySelectorAll('model-viewer').forEach((m) => push(m.getAttribute('src'), 'model', 'model-viewer'));
  document.querySelectorAll('a-asset-item, a-asset, a-entity[model-src], a-entity[src]').forEach((el) => {
    const s = el.getAttribute('src') || el.getAttribute('model-src') || el.getAttribute('gltf-model');
    push(s, 'model', 'a-frame');
  });
  // 2) <a href> 直链
  document.querySelectorAll('a[href]').forEach((a) => {
    if (MODEL_RE.test(a.href)) push(a.href, 'model', 'a[href]');
    else if (ARCH_RE.test(a.href)) push(a.href, 'archive', 'a[href]');
  });
  // 2.5) 网盘分享链接：压缩包/模型常经网盘分发，页面本体（如模型详情页）只有分享主页 URL，无直链。
  //      捕获为 'netdisk' 类型，侧栏可一键打开提取页，进入后再由网盘 API / 浏览器下载事件捕获真实文件。
  const NETDISK_RE = /(pan\.baidu\.com\/s\/|lanzou[s]?\.com|lanzaou\.com|quark\.cn|123pan\.com|aliyundrive\.com|weiyun\.com|cowtransfer\.com|ctfile\.com|mediafire\.com|mega\.nz|drive\.google\.com\/file|dropbox\.com\/s|terabox|pcloud)/i;
  document.querySelectorAll('a[href]').forEach((a) => {
    if (NETDISK_RE.test(a.href)) push(a.href, 'netdisk', 'a[href]');
  });
  // 3) 任意元素属性上含模型/归档扩展名的 URL（data-*/data-download-url/data-file/data-model/下载按钮属性等）。
  //    3D 站常把下载地址藏在按钮/div 的属性里，而非 <a href>。
  document.querySelectorAll('*').forEach((el) => {
    el.getAttributeNames().forEach((name) => {
      const v = el.getAttribute(name);
      if (!v || typeof v !== 'string') return;
      const m = v.match(URL_RE);
      if (m) {
        const u = m[0];
        if (MODEL_RE.test(u)) push(u, 'model', 'attr:' + name);
        else if (ARCH_RE.test(u)) push(u, 'archive', 'attr:' + name);
        else if (NETDISK_RE.test(u)) push(u, 'netdisk', 'attr:' + name);
        // 其余普通 URL（如 /api 接口）不匹配扩展名，跳过，避免误判为归档污染列表
      }
    });
  });
  // 4) 内联脚本 / JSON-LD / JSON 中埋的模型/归档直链
  document.querySelectorAll('script:not([src]), script[type="application/ld+json"], script[type="application/json"]').forEach((s) => {
    const urls = (s.textContent || '').match(URL_RE) || [];
    urls.forEach((u) => {
      if (MODEL_RE.test(u)) push(u, 'model', 'script');
      else if (ARCH_RE.test(u)) push(u, 'archive', 'script');
      else if (NETDISK_RE.test(u)) push(u, 'netdisk', 'script');
    });
  });
  // 5) 页面全局变量（模型站常把模型列表挂在 window 上，如 modelList/models/asset 等）
  try {
    ['modelList', 'models', 'modelData', 'assetList', 'assets', 'modelInfo', 'playerData', 'sceneData', 'MODEL_DATA', '__MODEL__', 'downloadUrl', 'fileUrl', 'resourceInfo'].forEach((k) => {
      const obj = window[k];
      if (!obj) return;
      const urls = JSON.stringify(obj).match(URL_RE) || [];
      urls.forEach((u) => {
        if (MODEL_RE.test(u)) push(u, 'model', 'global');
        else if (ARCH_RE.test(u)) push(u, 'archive', 'global');
        else if (NETDISK_RE.test(u)) push(u, 'netdisk', 'global');
      });
    });
  } catch (_) {}

  // ShadowDOM 内部资源（现代站点大量使用）
  const scanRoot = (root) => {
    root.querySelectorAll('img').forEach((img) => push(img.currentSrc || img.src, 'image', 'shadow-img'));
    root.querySelectorAll('video').forEach((v) => push(v.src, 'video', 'shadow-video'));
    root.querySelectorAll('audio').forEach((a) => push(a.src, 'audio', 'shadow-audio'));
    root.querySelectorAll('model-viewer').forEach((m) => push(m.getAttribute('src'), 'model', 'shadow-model'));
    root.querySelectorAll('*').forEach((el) => {
      if (el.shadowRoot) scanRoot(el.shadowRoot);
    });
  };
  document.querySelectorAll('*').forEach((el) => {
    if (el.shadowRoot) scanRoot(el.shadowRoot);
  });

  // 网络层捕获（引擎加载的 GLB / 音频缓冲 / 视频流）
  // ★透传原始 source（api-capture / audio-playback / youtube 等），不要硬编码覆盖成 'network'，
  // 侧栏与测试依赖 source 区分捕获来源。
  (networkAssets || []).forEach((a) => push(a.url, a.type, (a && a.source) || 'network'));

  // 动态链接自动重扫：站点把下载/网盘/模型链接在「点击按钮」或「接口回调」后才注入 DOM
  // （如 yunqiaonet 登录态）。静态扫描读不到 → 安装 MutationObserver，DOM 新增匹配链接时通知后台去抖重扫。
  try {
    if (!window.__hmdao_mutation_watch) {
      window.__hmdao_mutation_watch = true;
      const RE = /(pan\.baidu\.com\/s\/|lanzou|quark|123pan|aliyundrive|\.(glb|gltf|obj|fbx|zip|rar|7z|max|blend|c4d|dae|ply|3ds|skp|stl|usdz|mp4|webm|mov|mkv|flv|avi|wmv|ts|mpg|3gp)(\?|#|$))/i;
      let _mt = 0;
      const obs = new MutationObserver((muts) => {
        let hit = false;
        for (const m of muts) {
          for (const n of m.addedNodes) {
            if (n.nodeType !== 1) continue;
            if (RE.test(n.outerHTML || '')) { hit = true; break; }
            const as = n.querySelectorAll && n.querySelectorAll('a[href]');
            if (as) { for (const a of as) { if (RE.test(a.href)) { hit = true; break; } } }
            if (hit) break;
          }
          if (hit) break;
        }
        if (!hit) return;
        const now = Date.now();
        if (now - _mt < 2000) return; // 客户端节流，避免 MutationObserver 风暴
        _mt = now;
        if (typeof chrome !== 'undefined' && chrome.runtime) chrome.runtime.sendMessage({ type: 'HMDAO_PAGE_MUTATION' }).catch(() => {});
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }
  } catch (_) {}

  // ★零副作用「试听/切画质后自动刷新」（2026-08-01）：用户真点试听或切换画质、
  // model-api-capture.js 把音频/视频记进 window.__hmdao_captures 后，经 window.postMessage
  // 跨 world 通知本 ISOLATED 上下文 → 去抖转发后台触发 rescan，侧栏实时出现音效/多分辨率视频。
  // 纯被动：不主动点击/播放/切换画质，仅在真实发生后刷新。
  try {
    if (!window.__hmdao_audio_rescan_watch) {
      window.__hmdao_audio_rescan_watch = true;
      let _at = 0;
      window.addEventListener('message', (ev) => {
        try {
          if (!ev || !ev.data) return;
          const t = ev.data.__hmdao_type;
          if (t !== 'AUDIO_CAPTURED' && t !== 'VIDEO_CAPTURED') return;
          const now = Date.now();
          if (now - _at < 2000) return; // 去抖，避免连点风暴
          _at = now;
          if (typeof chrome !== 'undefined' && chrome.runtime) {
            chrome.runtime.sendMessage({ type: 'HMDAO_PAGE_MUTATION' }).catch(() => {});
          }
        } catch (_) {}
      });
    }
  } catch (_) {}

  // ★图片像素去重：同一张图常在不同位置以不同尺寸出现（缩略图 / 原图 / 带尺寸 query 参数的变体）。
  // 按 host+pathname 归组（忽略 query/hash 的尺寸参数），每组只保留「像素最大」的那张，其余小图剔除。
  // 优先用 <img> 的 naturalWidth*naturalHeight 比较；像素未知时回退按「原图来源优先」(a>img / img[data] 通常比 img / css-bg 更大)。
  {
    const imgIdx = [];
    out.forEach((a, i) => { if (a.type === 'image') imgIdx.push(i); });
    const groups = new Map();
    for (const i of imgIdx) {
      const a = out[i];
      let key;
      try {
        const u = new URL(a.url);
        key = u.host + u.pathname; // 抹掉 query/hash 的尺寸参数 → 同图不同尺寸合并
      } catch (_) {
        key = a.url;
      }
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(i);
    }
    const FULL_PREF = { 'a>img': 0, 'img[data]': 1, 'img[srcset]': 2, 'shadow-img': 3, 'video[poster]': 4, 'css-bg': 5, 'picture': 5, 'img': 6 };
    const drop = new Set();
    for (const [, idxs] of groups) {
      if (idxs.length < 2) continue;
      let best = idxs[0];
      for (const j of idxs) {
        const a = out[j], b = out[best];
        const pa = a.px || 0, pb = b.px || 0;
        if (pa !== pb) { if (pa > pb) best = j; continue; }
        // 像素相同/都未知：原图来源优先
        const ra = FULL_PREF[a.source] != null ? FULL_PREF[a.source] : 99;
        const rb = FULL_PREF[b.source] != null ? FULL_PREF[b.source] : 99;
        if (ra < rb) best = j;
      }
      for (const j of idxs) if (j !== best) drop.add(j);
    }
    if (drop.size) {
      const kept = [];
      out.forEach((a, i) => { if (!drop.has(i)) kept.push(a); });
      out = kept;
    }
  }

  // 合集/列表页检测（借鉴 seekin.ai 的「抖音合集」能力）：当前页面是合集时，
  // 注入一条 type:'playlist' 资产，侧栏可展开批量选择下载。抖音合集页 URL 多为
  // /collection/xxx 或带 mix_id/playlist_id；B站/优酷等合集同理。
  try {
    const host = location.hostname.toLowerCase();
    const path = location.pathname.toLowerCase();
    const isCollection =
      /collection|mix_id|playlist|album|play_list|channel\/(\d+)\/mix/i.test(location.href) ||
      /\/collection\//.test(path) || /\/mix\//.test(path) || /\/playlist\//.test(path);
    if (isCollection && (host.includes('douyin') || host.includes('bytedance') || host.includes('xinpianchang') || host.includes('bilibili') || host.includes('youku') || host.includes('iqiyi'))) {
      // 避免重复注入：若已存在同页 playlist 资产则跳过
      const hasPlaylist = out.some((a) => a.type === 'playlist' && a.playerUrl === location.href);
      if (!hasPlaylist) {
        out.push({
          type: 'playlist',
          url: location.href,
          playerUrl: location.href,
          title: (document.title || '合集').replace(/\s*[-_|]\s*(抖音|新片场|哔哩哔哩|优酷|爱奇艺).*$/i, '').trim() || '合集',
          name: '合集',
          source: 'collection-page',
          isCollection: true,
        });
      }
    }
  } catch (_) {}

  // ★根因 B 修复：原 out.slice(0, 800) 会把排在最后的 3D/归档条目裁掉（图片/视频/音频段先跑，画廊页极易超 800）。
  // 改为：模型/归档/网盘条目永远保留，只在图片/视频/音频里做预算裁剪。
  const CAP = 800;
  if (out.length <= CAP) return out;
  const priority = out.filter((a) => a.type === 'model' || a.type === 'archive' || a.type === 'netdisk' || a.type === 'playlist');
  const media = out.filter((a) => a.type !== 'model' && a.type !== 'archive' && a.type !== 'netdisk' && a.type !== 'playlist');
  const room = Math.max(0, CAP - priority.length);
  return priority.concat(media.slice(0, room));
}

// 视频封面采集（注入 MAIN 世界运行，自包含，禁止引用 background 作用域）。
// 返回 { byKey:{<video直链>:<封面URL>}, defaultCover:<页面默认封面>, pageCovers:[{kind,url}] }。
// - byKey：优先用平台直链键匹配（B站 playurl 直链↔__INITIAL_STATE__ 封面命中率有限，故主要依赖 defaultCover/pageCovers 兜底）。
// - defaultCover：B站 videoData.pic / 抖音 aweme.cover —— 同页视频资产的最佳封面。
// - pageCovers：页面所有 <video poster> —— 通用站点兜底封面。
function extractVideoCovers() {
  const byKey = {};
  let defaultCover = '';
  const pageCovers = [];
  try {
    // 1) B站封面：window.__INITIAL_STATE__.videoData.pic（已 URL编码，需解码）
    try {
      const ini = window.__INITIAL_STATE__;
      if (ini && ini.videoData && ini.videoData.pic) {
        defaultCover = decodeURIComponent(ini.videoData.pic);
      }
    } catch (_) {}
    // 2) 抖音/视频号封面：RENDER_DATA 里 aweme.cover
    if (!defaultCover) {
      try {
        const el = document.querySelector('script#RENDER_DATA, script[id="RENDER_DATA"]');
        if (el && el.textContent) {
          const data = JSON.parse(decodeURIComponent(el.textContent));
          let chosen = null;
          const targetId = (function () {
            try {
              const u = new URL(location.href);
              return u.searchParams.get('modal_id') || u.searchParams.get('aweme_id') || u.searchParams.get('feedid') || u.searchParams.get('id') || '';
            } catch (_) { return ''; }
          })();
          const walk = (o) => {
            if (!o || typeof o !== 'object') return;
            if (Array.isArray(o)) { o.forEach(walk); return; }
            const hasV = o.video && (o.video.play_addr || o.video.download_addr);
            if ((o.aweme_id || hasV) && !chosen) chosen = o;
            if (targetId && String(o.aweme_id) === String(targetId)) chosen = o;
            for (const k in o) { try { walk(o[k]); } catch (_) {} }
          };
          walk(data);
          if (chosen && chosen.video && chosen.video.cover) {
            const cl = (chosen.video.cover.url_list || []);
            if (cl.length) {
              const c = cl[0].replace(/\\\//g, '/');
              defaultCover = c;
              // 抖音封面通常无水印，作为 byKey 键（以 aweme_id 视频直链兜底由 scan.js 同页兜底处理）
              byKey['aweme:' + (chosen.aweme_id || targetId)] = c;
            }
          }
        }
      } catch (_) {}
    }
    // 3) 新片场封面：页面内嵌 __INITIAL_STATE__ / RENDER_DATA 里的 cover / poster / video_pic 字段
    if (!defaultCover || pageCovers.length === 0) {
      try {
        const scripts = Array.from(document.querySelectorAll('script'))
          .map((s) => s.textContent || '').filter((t) => t && /xinpianchang|cover|poster|video_pic|pic/i.test(t));
        for (const t of scripts) {
          // 宽松匹配 "...cover":"https://..." 或 "...poster":"..." 或 "...video_pic":"..."
          const mm = t.match(/"\s*(?:cover|poster|video_pic|pic)\s*"\s*:\s*"\s*(https?:[^"\\{}]+?\.(?:jpg|jpeg|png|webp)(?:\?[^"\\{}]*)?)\s*"/i)
            || t.match(/https?:\/\/[^"'\\<>\s]+\.xinpianchang\.com[^"'\\<>\s]+\.(?:jpg|jpeg|png|webp)/i);
          if (mm) {
            const c = (mm[1] || mm[0]).replace(/\\\//g, '/');
            if (!defaultCover) defaultCover = c;
            pageCovers.push({ kind: 'xinpianchang', url: c });
            break;
          }
        }
      } catch (_) {}
    }
    // 4) 通用 <video poster>（含 data-src 兜底）
    document.querySelectorAll('video').forEach((v) => {
      let p = v.getAttribute('poster') || v.poster;
      if (!p && v.dataset) p = v.dataset.poster || v.dataset.cover || v.dataset.thumbnail;
      if (p) {
        try { p = new URL(p, location.href).href; } catch (_) {}
        pageCovers.push({ kind: 'poster', url: p });
      }
    });
    // 4) og:image / twitter:image 作为通用默认封面（Pexels/Coverr 等专业视频源常用）
    if (!defaultCover) {
      try {
        const og = document.querySelector('meta[property="og:image"], meta[name="twitter:image"]');
        if (og) {
          const c = og.getAttribute('content');
          if (c) { defaultCover = new URL(c, location.href).href; }
        }
      } catch (_) {}
    }
  } catch (_) {}
  return { byKey, defaultCover, pageCovers };
}

if (typeof globalThis !== 'undefined') {
  globalThis.scanTab = scanTab;
  globalThis.scanPage = scanPage;
}
