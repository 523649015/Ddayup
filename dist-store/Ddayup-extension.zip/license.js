// Ddayup 素材采集扩展 · 登录 / 7 天免费试用 / 付费许可闸门
// 与后端 /api/extension/* 配合；授权判定以服务端为准，本文件只做展示与动作拦截。
(function () {
  // API 地址：默认本机 3000，可由 config.setApiBase() 经 chrome.storage 覆盖（上云时用）。
  // 与 extension/config.js 共用 storage key 'ddayupApiBase'，保证单点配置。
  function apiBase() {
    return licenseState.apiBaseCache || 'http://127.0.0.1:3000';
  }
  const TRIAL_DAYS = 7;
  // 上架模式：true=免费版（试用过期不阻断核心功能，仅提示，符合 Edge 审核"不声明付费功能"要求）。
  // 与 config.js 的 FREE_MODE 同源；接真实支付后改为 false（需配套价格+退款政策）。
  const FREE_MODE = true;
  const licenseState = { apiBaseCache: 'http://127.0.0.1:3000' };
  // 启动时异步读取覆盖值（不改同步默认行为，避免首屏闪烁/报错）
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get('ddayupApiBase', (o) => {
      const v = o && o.ddayupApiBase;
      if (v && /^https?:\/\//.test(v)) licenseState.apiBaseCache = v.replace(/\/+$/, '');
    });
  }

  function getDeviceId() {
    return new Promise((resolve) => {
      chrome.storage.local.get('hmdaoDeviceId', (o) => {
        if (o && o.hmdaoDeviceId) return resolve(o.hmdaoDeviceId);
        const id = 'dd-' + (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));
        chrome.storage.local.set({ hmdaoDeviceId: id }, () => resolve(id));
      });
    });
  }

  function postJSON(p, body) {
    return fetch(apiBase() + p, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then((r) => r.json().catch(() => ({ success: false })));
  }

  async function refreshState() {
    const deviceId = await getDeviceId();
    const cached = await new Promise((res) => chrome.storage.local.get('hmdaoLicense', (o) => res(o.hmdaoLicense || null)));
    let st = null;
    try { st = await postJSON('/api/extension/license/status', { deviceId }); } catch (_) { /* 离线用缓存 */ }
    if (!st || st.success === false) {
      return cached || { mode: 'trial', trialDaysLeft: TRIAL_DAYS, offline: true };
    }
    const merged = Object.assign({}, st, { cachedAt: Date.now() });
    chrome.storage.local.set({ hmdaoLicense: merged });
    return merged;
  }

  async function ensureTrial() {
    const deviceId = await getDeviceId();
    const st = await refreshState();
    if (st.mode === 'none') {
      try { await postJSON('/api/extension/trial/start', { deviceId }); } catch (_) {}
    }
    return refreshState();
  }

  async function login(email, password) {
    const deviceId = await getDeviceId();
    const r = await postJSON('/api/extension/account/login', { email, password, deviceId });
    if (r && r.success) {
      chrome.storage.local.set({ hmdaoToken: r.token, hmdaoLicense: Object.assign({}, r, { cachedAt: Date.now() }) });
    }
    return r;
  }

  async function activate(key) {
    const deviceId = await getDeviceId();
    const r = await postJSON('/api/extension/license/activate', { deviceId, key });
    if (r && r.success) {
      chrome.storage.local.set({ hmdaoLicense: Object.assign({}, r, { cachedAt: Date.now() }) });
    }
    return r;
  }

  function showPaywall(state, block) {
    const el = document.getElementById('licensePaywall');
    if (!el) return;
    // 非阻断模式（免费版 expired）：不弹付费墙，仅更新状态徽章提示。
    if (block === false) { hidePaywall(); updateTrialBadge(state); return; }
    el.style.display = 'flex';
    const info = el.querySelector('#lpInfo');
    if (info) {
      if (state && state.mode === 'expired') {
        info.textContent = `免费试用已结束（${TRIAL_DAYS} 天）。请登录账号或激活付费许可证后继续使用素材采集。`;
      } else if (state && state.mode === 'trial') {
        info.textContent = `免费试用剩余 ${state.trialDaysLeft != null ? state.trialDaysLeft : TRIAL_DAYS} 天。可登录账号或激活许可证以长期使用。`;
      } else {
        info.textContent = `登录账号或激活许可证以开始使用 Ddayup 素材采集。`;
      }
    }
    updateTrialBadge(state);
  }
  function hidePaywall() {
    const el = document.getElementById('licensePaywall');
    if (el) el.style.display = 'none';
  }
  function updateTrialBadge(state) {
    const badge = document.getElementById('trialBadge');
    if (!badge) return;
    if (state && state.mode === 'paid') { badge.textContent = '已授权'; badge.className = 'lic-badge paid'; }
    else if (state && state.mode === 'trial') { badge.textContent = `试用 ${state.trialDaysLeft != null ? state.trialDaysLeft : TRIAL_DAYS}天`; badge.className = 'lic-badge trial'; }
    else if (state && state.mode === 'expired') { badge.textContent = '已过期'; badge.className = 'lic-badge expired'; }
    else { badge.textContent = ''; badge.className = 'lic-badge'; }
  }

  async function gate() {
    const st = await refreshState();
    if (st.mode === 'expired') {
      // 免费版（FREE_MODE）下：仅提示，不阻断核心采集功能，符合 Edge 审核要求。
      if (FREE_MODE) { showPaywall(st, /*block*/ false); updateTrialBadge(st); return true; }
      showPaywall(st, /*block*/ true); return false;
    }
    hidePaywall();
    updateTrialBadge(st);
    return true;
  }

  function wirePaywall() {
    const el = document.getElementById('licensePaywall');
    if (!el) return;
    const lpStatus = el.querySelector('#lpStatus');
    el.querySelector('#lpLogin').addEventListener('click', async () => {
      const email = el.querySelector('#lpEmail').value.trim();
      const pwd = el.querySelector('#lpPassword').value;
      lpStatus.textContent = '登录中…';
      const r = await login(email, pwd);
      if (r && r.success) { lpStatus.textContent = '登录成功，试用期已激活。'; hidePaywall(); updateTrialBadge(r); }
      else { lpStatus.textContent = (r && r.error && r.error.message) || '登录失败'; }
    });
    el.querySelector('#lpActivate').addEventListener('click', async () => {
      const key = el.querySelector('#lpKey').value.trim();
      lpStatus.textContent = '激活中…';
      const r = await activate(key);
      if (r && r.success) { lpStatus.textContent = '激活成功，感谢支持！'; hidePaywall(); updateTrialBadge(r); }
      else { lpStatus.textContent = (r && r.error && r.error.message) || '激活失败'; }
    });
    const close = el.querySelector('#lpClose');
    if (close) close.addEventListener('click', () => hidePaywall());
  }

  // 自动初始化：确保试用已启动，过期则弹出付费墙
  async function init() {
    try {
      const st = await ensureTrial();
      updateTrialBadge(st);
      if (st.mode === 'expired') showPaywall(st);
      else hidePaywall();
    } catch (_) { /* 后端不可达：不打断采集，仅不显示墙 */ }
  }

  window.HMDaoLicense = {
    getDeviceId, refreshState, ensureTrial, login, activate, showPaywall, hidePaywall, gate, TRIAL_DAYS,
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { wirePaywall(); init(); });
  } else {
    wirePaywall(); init();
  }
})();
