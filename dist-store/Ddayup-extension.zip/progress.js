// ===== 下载进度条（抽离 UI 控制，共享全局作用域）=====
// 两种进度来源：
//  1) chrome.downloads.download —— 监听 onChanged 的 bytesReceived/totalBytes，显示真实百分比。
//  2) fetch+Blob 路径（yt-dlp 合并 / fetchViaBackground / fetchMediaViaBackground）——
//     后台一次性缓冲整段响应后回传，无逐字节回调，故显示「不确定进度」条纹动画，让用户知道正在拉取。

// 当前活跃的确定进度项（按 downloadId 索引），用于 onChanged 增量更新
const __dlProgressItems = {};

function __dlProgressEl() { return document.getElementById('dlProgress'); }

function fmtBytes(n) {
  if (!n && n !== 0) return '';
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
  return (n / 1024 / 1024 / 1024).toFixed(2) + ' GB';
}

// 打开一个「真实百分比」进度项（对应一次 chrome.downloads.download）
function showDownloadProgress(name, downloadId) {
  const el = __dlProgressEl();
  if (!el) return;
  __dlProgressItems[downloadId || 'single'] = { name, indeterminate: false };
  el.style.display = '';
  el.querySelector('#dlProgressIcon').className = 'dlProgressIcon';
  el.querySelector('#dlProgressIcon').textContent = '⬇';
  el.querySelector('#dlProgressName').textContent = name || '下载中…';
  el.querySelector('#dlProgressPct').textContent = '';
  const bar = el.querySelector('#dlProgressBar');
  bar.className = 'dlProgressBar';
  bar.style.width = '0%';
}

// 打开一个「不确定进度」条（fetch+Blob 路径，无字节回调）
function pulseDownloadProgress(text) {
  const el = __dlProgressEl();
  if (!el) return;
  __dlProgressItems.pulse = { name: text, indeterminate: true };
  el.style.display = '';
  el.querySelector('#dlProgressIcon').className = 'dlProgressIcon';
  el.querySelector('#dlProgressIcon').textContent = '⬇';
  el.querySelector('#dlProgressName').textContent = text || '正在拉取…';
  el.querySelector('#dlProgressPct').textContent = '';
  const bar = el.querySelector('#dlProgressBar');
  bar.className = 'dlProgressBar indeterminate';
}

// 更新真实百分比（received / total，单位字节）
function updateDownloadProgress(downloadId, received, total) {
  const el = __dlProgressEl();
  if (!el) return;
  // onChanged 可能在 dlViaChrome 的 .then(id) 落地前就触发，故查不到 downloadId 时回退到 'single' 项
  const item = __dlProgressItems[downloadId] || __dlProgressItems.single;
  if (!item) return;
  __dlProgressItems[downloadId] = item; // 落定真实键，后续增量更新即命中
  el.querySelector('#dlProgressName').textContent = item.name || '下载中…';
  const bar = el.querySelector('#dlProgressBar');
  bar.className = 'dlProgressBar';
  const pctEl = el.querySelector('#dlProgressPct');
  if (total && total > 0) {
    const pct = Math.max(0, Math.min(100, (received / total) * 100));
    bar.style.width = pct.toFixed(1) + '%';
    pctEl.textContent = Math.round(pct) + '% · ' + fmtBytes(received) + ' / ' + fmtBytes(total);
  } else {
    // 未知总大小：用收到字节数显示，进度条保持脉冲
    bar.className = 'dlProgressBar indeterminate';
    pctEl.textContent = fmtBytes(received);
  }
}

function finishDownloadProgress(name, ok) {
  const el = __dlProgressEl();
  if (!el) return;
  // 清理所有项
  for (const k of Object.keys(__dlProgressItems)) delete __dlProgressItems[k];
  const icon = el.querySelector('#dlProgressIcon');
  icon.className = 'dlProgressIcon ' + (ok ? 'done' : 'fail');
  icon.textContent = ok ? '✅' : '⚠';
  if (name) el.querySelector('#dlProgressName').textContent = name;
  el.querySelector('#dlProgressPct').textContent = ok ? '完成' : '失败';
  const bar = el.querySelector('#dlProgressBar');
  bar.className = 'dlProgressBar';
  bar.style.width = ok ? '100%' : bar.style.width;
  // 3.5s 后自动隐藏
  if (window.__dlProgressHideTimer) clearTimeout(window.__dlProgressHideTimer);
  window.__dlProgressHideTimer = setTimeout(() => { el.style.display = 'none'; }, 3500);
}

// 隐藏（如被覆盖错误用）
function hideDownloadProgress() {
  const el = __dlProgressEl();
  if (el) el.style.display = 'none';
  for (const k of Object.keys(__dlProgressItems)) delete __dlProgressItems[k];
}
