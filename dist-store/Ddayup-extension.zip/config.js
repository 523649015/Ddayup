// Ddayup 网页素材采集扩展 · 运行时配置层
// 设计目标：把原先硬编码的 http://127.0.0.1:3000 收敛为可配置项，支持后续上云（改一处即可）。
// 默认值与现有行为一致（localhost:3000），不破坏任何既有功能。
const DEFAULT_API_BASE = 'http://127.0.0.1:3000';
const STORAGE_KEY = 'ddayupApiBase';

// 上架模式：true=免费版（试用过期不阻断核心功能，仅提示，符合 Edge 审核"不声明付费功能"要求）。
// 接真实支付后改为 false（届时需配套价格+退款政策）。
export const FREE_MODE = true;

// 已适配采集策略的平台列表（对应上架计划 P1 2.1）。
// 每项：id 内部标识；label 展示名；hosts 匹配域名（用于 content script / 权限白名单参考）；
// coverSource 封面获取方式（page-global=页面全局变量；render-data=RENDER_DATA；poster=video poster 兜底；og=og:image）。
export const SUPPORTED_PLATFORMS = [
  { id: 'bilibili', label: 'B站', hosts: ['*.bilibili.com'], coverSource: 'page-global(__INITIAL_STATE__.videoData.pic)' },
  { id: 'youtube', label: 'YouTube', hosts: ['*.youtube.com', '*.youtu.be'], coverSource: 'page-global(ytInitialPlayerResponse.videoDetails.thumbnail)' },
  { id: 'douyin', label: '抖音', hosts: ['*.douyin.com'], coverSource: 'render-data(RENDER_DATA aweme.cover, 经 relay 带 Referer 拉取)' },
  { id: 'weixin-channels', label: '视频号', hosts: ['*.weixin.qq.com', '*.channels.weixin.qq.com'], coverSource: 'render-data(RENDER_DATA, 需登录态)' },
  { id: 'xinpianchang', label: '新片场', hosts: ['*.xinpianchang.com'], coverSource: 'render-data/og:image' },
  { id: 'aigei', label: '爱给', hosts: ['*.aigei.com'], coverSource: 'audio-playback(音频无封面, 用波形图标)' },
  { id: 'gfxcamp', label: 'gfxcamp', hosts: ['*.gfxcamp.com'], coverSource: 'netdisk(百度网盘分享, 无直链封面)' },
  { id: 'yunqiaonet', label: '云桥网', hosts: ['*.yunqiaonet.com'], coverSource: 'netdisk(需登录购买后注入)' },
];

// 同步读取（首屏用，避免异步闪烁）。chrome.storage 在扩展上下文始终可用。
function readStoredBaseSync() {
  try {
    // MV3 下 chrome.storage.local.get 为异步，这里用同步兜底返回默认值；
    // 真正覆盖值由 getApiBase() 异步返回后填入运行时缓存。
    return null;
  } catch {
    return null;
  }
}

let cache = readStoredBaseSync();

// 异步获取当前 API_BASE：优先 storage 覆盖，否则默认 localhost:3000
export async function getApiBase() {
  if (cache) return cache;
  try {
    const res = await chrome.storage.local.get(STORAGE_KEY);
    const v = res && res[STORAGE_KEY];
    if (v && typeof v === 'string' && /^https?:\/\//.test(v)) {
      cache = v.replace(/\/+$/, '');
      return cache;
    }
  } catch {
    // 忽略：保持默认
  }
  cache = DEFAULT_API_BASE;
  return cache;
}

// 写入覆盖值（上云时调用一次即可持久化）
export async function setApiBase(base) {
  const v = (base || '').trim().replace(/\/+$/, '');
  if (!/^https?:\/\//.test(v)) return false;
  cache = v;
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: v });
    return true;
  } catch {
    return false;
  }
}

export function defaultApiBase() {
  return DEFAULT_API_BASE;
}

// 原生主机名称（方案 A）。与 native-host 注册表/manifest 中声明的 name 必须一致。
export const NATIVE_HOST_NAME = 'com.ddayup.host';
