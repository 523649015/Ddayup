// MAIN-world 拦截器（由 manifest 以 "world":"MAIN" 注入模型/资源站）。

// ===== B站播放页熔断（兼容 B站原生播放器）=====
// 实测：在 B站视频播放页（bilibili.com/video/）即便只「监听」fetch/XHR 响应，
// 也会因微任务时序变化导致 B站播放器读取 playurl 配置（nc_policy / reward_pcdn_loader_policy）
// 时对象为 undefined，进而视频加载失败。为彻底兼容，B站播放页直接跳过全部 patch，
// 让扩展在该页面 100% 静默（与「无扩展」行为完全一致）。侧栏采集仍可在 B站列表/首页页工作，
// 但不在视频播放页注入。
function __hmdao_isBiliPlayPage() {
  try {
    const h = location.hostname || '';
    return (h.endsWith('bilibili.com') || h.endsWith('b23.tv')) && /\/(video|blackboard\/.*play|festival)\//.test(location.pathname);
  } catch (_) { return false; }
}

// ★抖音/TikTok 播放页熔断（2026-08-02，零干扰规范 §2.2）：与 B站同级别 100% 静默。
function __hmdao_isDouyinPlayPage() {
  try {
    const h = location.hostname || '';
    return /(^|\.)douyin\.com$/.test(h) || /(^|\.)iesdouyin\.com$/.test(h) || /(^|\.)tiktok\.com$/.test(h);
  } catch (_) { return false; }
}

// 目标：爱给 / CG模型 等站的 3D 模型、压缩包下载地址是「点下载按钮才由下载 API 动态签名返回」的，
// DOM 静态扫描（scanPage）拿不到，chrome.webRequest 又读不到响应体。
// 故在页面主世界 patch fetch/XHR，解析下载 API 响应里的 fileUrl/cdnLink/url 字段，
// 把签名的 .zip/.glb/.fbx 等真实地址存入 window.__hmdao_model_hits，
// 由 background 扫描/轮询时以 world:'MAIN' 的 executeScript 读取（MAIN 世界不可 sendMessage）。

// ===== 纯函数（浏览器与 Node 测试共用，避免算法漂移） =====
const MODEL_RE = /\.(glb|gltf|obj|fbx|stl|usdz|max|blend|ma|mb|c4d|dae|ply|3ds|skp|wrl|x3d|abc|lwo|smd|vrm|ase|dxf|bvh)([?#]|$)/i;
const ARCH_RE = /\.(zip|rar|7z|tar\.gz|tgz|tar\.bz2|gz|bz2|tar|iso|cab|jar|z|lzh|ace|arj)([?#]|$)/i;
// 下载型 API 特征（含网盘 list/download 接口）。覆盖 pan.baidu.com 的 /api/list、/api/download 等。
const API_RE = /(\/download|\/resource|\/package|\/file|\/geturl|\/downfile|\/down|\/list|\/sharedownload|\/api\/[^\s"']*(file|download|resource|attachment|asset|list|getfile|sharedownload))/i;
const URL_RE = /https?:\/\/[^"')\s\\]+/gi;

// 分类：URL 带模型/归档扩展名直接判；否则用文件名（网盘 dlink 无扩展名、但 server_filename 带扩展名）作线索。
function classify(u, filenameHint) {
  if (typeof u === 'string' && (MODEL_RE.test(u) || ARCH_RE.test(u))) {
    return ARCH_RE.test(u) ? 'archive' : 'model';
  }
  if (filenameHint && (MODEL_RE.test(filenameHint) || ARCH_RE.test(filenameHint))) {
    return ARCH_RE.test(filenameHint) ? 'archive' : 'model';
  }
  return null;
}

// 从响应体文本中萃取出所有「模型/压缩包」直链（含 fileUrl/cdnLink/url/dlink 等 JSON 字段）。
// 返回 [{ url, type }]，type 由 URL 扩展名或「配对的 server_filename」推断（网盘 dlink 无扩展名时靠文件名）。
function extractDownloadUrls(text) {
  if (!text || typeof text !== 'string') return [];
  const out = [];
  const seen = new Set();
  const add = (u, t) => {
    if (!u || !t) return;
    if (/[?&](thumb|preview|cover|small|tiny|avatar)/i.test(u)) return;
    const key = u + '|' + t;
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ url: u, type: t });
  };
  const isDlUrl = (s) => /^https?:\/\//i.test(s)
    && /(dlink|download_url|downloadurl|downurl|file_url|fileurl|\/download|\/file\/|\/getfile|\/downfile)/i.test(s)
    && !/\.(html?|php|asp)(\?|$)/i.test(s);
  const isFileName = (s) => /\.(zip|rar|7z|tar\.gz|tgz|tar\.bz2|gz|iso|cab|jar|z|lzh|glb|gltf|fbx|obj|blend|max|c4d|dae|ply|3ds|skp|stl|usdz|abc|lwo|smd|vrm)(\?|$)/i.test(s);
  // 1) 直接 URL（带扩展名）。先对正文做轻度转义还原，兼容爱给等把签名 URL
  //    用 Unicode/HTML 实体转义下发的情况（JSON.stringify 后会是双反斜杠 \\u0026）。
  const norm = (text || '')
    .replace(/\\\\u0026/g, '&')
    .replace(/\\u0026/g, '&')
    .replace(/&#47;/g, '/')
    .replace(/\\u002f/gi, '/');
  let m;
  URL_RE.lastIndex = 0;
  while ((m = URL_RE.exec(norm))) {
    const u = m[0];
    const t = classify(u);
    if (t) add(u, t);
  }
  // 2) JSON：递归配对网盘「dlink + server_filename」「download_url + filename」等
  try {
    const obj = JSON.parse(text);
    const dlUrls = [];
    const fileNames = [];
    const pairObject = (o) => {
      if (!o || typeof o !== 'object') return;
      let dl = null, fn = null;
      for (const k in o) {
        const v = o[k];
        if (typeof v !== 'string') continue;
        if (/^(dlink|download_url|downloadurl|downurl|file_url|fileurl)$/i.test(k) && /^https?:\/\//i.test(v)) dl = v;
        if (/^(server_filename|filename|file_name|name|fname)$/i.test(k) && isFileName(v)) fn = v;
      }
      if (dl && fn) add(dl, classify(dl, fn));
    };
    const rec = (o, depth) => {
      if (!o || depth > 10) return;
      if (typeof o === 'string') {
        if (isDlUrl(o)) dlUrls.push(o);
        if (isFileName(o)) fileNames.push(o);
        return;
      }
      if (Array.isArray(o)) { o.forEach((v) => rec(v, depth + 1)); return; }
      if (typeof o === 'object') { pairObject(o); for (const k in o) rec(o[k], depth + 1); }
    };
    rec(obj, 0);
    // 启发式：有 dlink 但没和 filename 配对成功时，用任一文件名扩展名推断类型
    if (dlUrls.length && fileNames.length) {
      for (const u of dlUrls) add(u, classify(u, fileNames[0]));
    }
  } catch (_) { /* 非 JSON，已靠正则处理 */ }
  return out;
}

// 仅当「请求 URL 像下载 API」或「响应体含下载地址/网盘字段」时才处理，避免无谓开销/误报
function shouldInspect(url, bodyText) {
  if (API_RE.test(url || '')) return true;
  if (bodyText && /(fileurl|cdnlink|downloadurl|cdn_link|file_url|cos_url|oss_url|server_filename|dlink|isdir|path)/i.test(bodyText)) return true;
  return false;
}

// Node 单测导出（浏览器中 module 不存在，忽略）
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { extractDownloadUrls, classify, shouldInspect, MODEL_RE, ARCH_RE, API_RE };
}

// ===== 浏览器主世界注入（patch fetch/XHR） =====
(function () {
  if (typeof window === 'undefined' || window.__hmdao_model_capture) return;
  if (__hmdao_isBiliPlayPage()) return; // B站播放页熔断：不 patch，兼容原生播放器
  if (__hmdao_isDouyinPlayPage()) return; // 抖音/TikTok 播放页熔断：不 patch，兼容原生播放器
  window.__hmdao_model_capture = true;

  // 站点经私有 API 直接返回 glb/gltf 二进制（URL 无 .glb 扩展名、content-type 也非 model/，
  // 例 tripo3d 等查看器加载模型 → 扫描器与网络层都抓不到）。按「URL 形态」预判是否可能含模型二进制。
  function looksModelUrl(url) {
    return /(^|[?/&.])(glb|gltf|glbz|usdz?|fbx|obj|stl|ply|3ds|max|blend|dae|model|task|asset|resource|mesh|pbr|render|preview)s?([?/&#.]|$)/i.test(url || '');
  }
  // Uint8Array → base64（分块避免 call stack 超限）
  function abToB64(u8) {
    let s = '';
    const chunk = 0x8000;
    for (let i = 0; i < u8.length; i += chunk) s += String.fromCharCode.apply(null, u8.subarray(i, i + chunk));
    return btoa(s);
  }

  // ★根因修复：本文件运行在【MAIN 世界】，网页主世界没有扩展消息通道 ——
  // chrome.runtime.sendMessage 要么 undefined 要么因缺 extensionId 直接抛错，被 try/catch 静默吞掉，
  // 导致下载 API 里解析出的 3D/压缩包直链【从未到达后台】（真实 3D 站识别不出的第一根因）。
  // 正确模式（与 inject-main 的 ytPlay 相同）：存 window.__hmdao_model_hits，
  // 由 background 在扫描/轮询时用 chrome.scripting.executeScript({world:'MAIN'}) 读取。
  function report(items) {
    (items || []).forEach((it) => {
      const u = typeof it === 'string' ? it : it.url;
      const t = typeof it === 'string' ? classify(it) : (it.type || (it.url ? classify(it.url) : null));
      if (!u || !t) return;
      const ext = (it && it.ext) || null;
      const inline = (it && it.inline) || null;
      try {
        const store = window.__hmdao_model_hits || (window.__hmdao_model_hits = []);
        // 内联字节按 url+type+已内联 去重，避免重复塞大字符串
        const dup = store.some((x) => x.url === u && x.type === t && (!inline || x.inline));
        if (!dup) {
          store.push({ url: u, type: t, ext, inline, ts: Date.now() });
          if (store.length > 300) store.shift();
        }
      } catch (_) {}
      // best-effort：若未来改为 ISOLATED 注入，此通道自动生效；MAIN 世界会抛错，忽略即可
      // 注意：inline 字节不在此通道传（base64 过大且 MAIN 世界 sendMessage 不可靠），靠 readAllCapturesMAIN 回读
      try {
        chrome.runtime.sendMessage({ type: 'HMDAO_MODEL_API_CAPTURE', url: u, assetType: t })
          .catch(() => {});
      } catch (_) {}
    });
  }

  try {
    const orig = window.fetch;
    window.fetch = function () {
      const url = (typeof arguments[0] === 'string' ? arguments[0] : (arguments[0] && arguments[0].url)) || '';
      let p;
      try {
        p = orig.apply(this, arguments);
      } catch (e) {
        throw e; // 保持原生同步异常语义（如非法 URL）
      }
      // ★通用音频捕获（WebAudio 按钮音效等走 fetch→decodeAudioData，不经 <audio> 元素）：
      // URL 带音频扩展名立即记录；无扩展名接口靠响应 content-type: audio/* 旁路判定。
      try { if (window.__hmdao_remember_audio && /\.(mp3|wav|flac|aac|m4a|ogg|opus|wma)([?#]|$)/i.test(url)) window.__hmdao_remember_audio(url, 'fetch'); } catch (_) {}
      // ★爱给等音效站 best-effort：防盗链接口常「无扩展名 + content-type 非 audio/*」，
      // 被动钩子会整条漏抓。这里按 host(媒体子域) + URL 路径(疑似播放接口) 或「签名参数」推断为音频并记录，
      // 零副作用（仅观察，不主动请求/播放）。2026-08-01 / 强化 2026-08-01。
      try {
        if (window.__hmdao_remember_audio) {
          let h = '';
          try { h = new URL(url).hostname; } catch (_) {}
          if (/(^|\.)aigei\.com$/i.test(h) || /(^|\.)aigei\.com$|alicdn\.com$|aliyuncs\.com$|aliyun\.com$|oss-/.test(url)) {
            const aigeiAudioPath = /\/(play|listen|voice|media|file|get|download|resource|api\/|bgm|effect|sfx|sound|yinxiao|bmg|music|mp3|wav|m4a|ogg)(\/|$|[?#])/i;
            // ★根因修复（2026-08-01）：旧版 aigeiNotAudio 把路径含 /class/ 的 URL 全排除，
            // 但爱给【分类页 /sound/class/ 内点试听】发出的播放请求路径也含 class（如 .../class/xxx/play?e=..&token=..），
            // 被一并误杀 → 重构后分类页试听采不到（重构前靠 webRequest 网络层不区分路径能采到）。
            // 修正：仅当「纯导航页」（路径停在 class/list/index 等导航段、且不含播放接口段、无签名参数）才排除；
            // 一旦命中播放接口路径或带音频签名参数，无论是否含 class，都判为音频。
            const aigeiNavOnly = /\/(class|index|list|category|search|tag|rank|topic)\/?$/i;
            // 真实爱给试听接口形如 ...?e=171xxxx&token=xxx（限时签名 URL，无扩展名、content-type 非 audio/*）。
            // 这类 URL 即使路径不在白名单，只要带音频签名参数即判为音频，彻底覆盖登录后点击试听漏抓。
            // ★且爱给真实音频常托管在 alicdn/OSS 外域 CDN（路径不含 aigei.com），故外域 CDN + 签名参数也记。
            const aigeiSigned = /[?&](e|token|t|sign|sk|expire|expires|k|fm|tt|x-oss-)/i;
            const isPlay = aigeiAudioPath.test(url);
            const isCDN = /(^|\.)aigei\.com$|alicdn\.com$|aliyuncs\.com$|aliyun\.com$|oss-/.test(url);
            const isSigned = aigeiSigned.test(url);
            const isNavOnly = aigeiNavOnly.test(url) && !isPlay && !isSigned;
            if ((isPlay && !isNavOnly) || (isSigned && !isNavOnly) || (isCDN && isSigned)) {
              window.__hmdao_remember_audio(url, 'aigei-besteffort');
            }
          }
        }
      } catch (_) {}
      if (p && typeof p.then === 'function' && window.__hmdao_remember_audio) {
        p.then(function (resp) {
          try {
            const rurl = (resp && resp.url) || url;
            const ct = (resp && resp.headers && resp.headers.get) ? (resp.headers.get('content-type') || '') : '';
            // ★放宽（2026-08-01）：爱给等站音频常托管在 alicdn/OSS，content-type 是 octet-stream 而非 audio/*，
            // 且 URL 无扩展名（带 e/token 签名）。旧逻辑只认 content-type:audio/* → 全漏 → 试听采不到。
            // 现在：audio/* 或 爱给域名/CDN 下带签名参数 或 音频扩展名，都记。
            const isAigei = /aigei\.com$|alicdn\.com$|aliyuncs\.com$|aliyun\.com$|oss-/.test(rurl);
            const aigeiSigned = /[?&](e|token|t|sign|sk|expire|expires|k|fm|tt|x-oss-)/i.test(rurl);
            const audioExt = /\.(mp3|wav|flac|aac|m4a|ogg|opus|wma|amr|mid|midi)([?#]|$)/i.test(rurl);
            if (/^audio\//i.test(ct) || (isAigei && aigeiSigned) || audioExt) {
              window.__hmdao_remember_audio(rurl, 'fetch-ct');
            } else if (isAigei && /application\/(octet-stream|.*download)|binary\//i.test(ct)) {
              window.__hmdao_remember_audio(rurl, 'fetch-ct'); // OSS 默认 octet-stream + 爱给域名：基本确定是音频直链
            }
          } catch (_) {}
          return resp;
        }).catch(function () {}); // 独立旁路，不影响页面 Promise
      }
      // 全站注入时，仅「下载型 API」或「明显是模型的 URL」才读取响应体，避免对视频等大响应体无谓读内存。
      const isApi = API_RE.test(url);
      const isModelReq = isApi || looksModelUrl(url);
      if (p && typeof p.then === 'function' && isModelReq) {
        // 关键修复：把「读取响应体做抓取」作为【独立旁路】，绝不改变返回给页面的原生 Promise。
        p.then(function (resp) {
          try {
            const ct = (resp && resp.headers && resp.headers.get) ? (resp.headers.get('content-type') || '') : '';
            const clHeader = parseInt((resp && resp.headers && resp.headers.get && resp.headers.get('content-length')) || '0', 10);
            // A) 文本：从下载 API 响应体里抽签名直链（既有逻辑）
            if (isApi && clHeader < 50 * 1024 * 1024) {
              const body = resp && resp.clone ? resp.clone() : resp;
              if (body && typeof body.text === 'function') {
                body.text().then(function (text) {
                  try { if (shouldInspect(url, text)) report(extractDownloadUrls(text)); } catch (_) {}
                }).catch(function () {});
              }
            }
            // B) 二进制：站点经私有 API 直接吐 glb/gltf 字节（URL 无 .glb 扩展名、content-type 也非 model/），
            //    例 tripo3d 等查看器加载模型 → 扫描器/网络层都抓不到。按魔数识别并【内联】捕获，
            //    后台读回后侧栏可直接预览/缩略图，绕开跨域与签名失效。
            const looksBinaryModel = /model\/|octet-stream|application\/x-tgif|gltf|mesh/i.test(ct) || looksModelUrl(url) || isApi;
            if (looksBinaryModel && clHeader < 80 * 1024 * 1024) {
              const bin = resp && resp.clone ? resp.clone() : resp;
              if (bin && typeof bin.arrayBuffer === 'function') {
                bin.arrayBuffer().then(function (ab) {
                  try {
                    const u8 = new Uint8Array(ab);
                    // glb 魔数 b'glTF'（偏移 0）
                    if (u8.length > 12 && u8[0] === 0x67 && u8[1] === 0x6c && u8[2] === 0x54 && u8[3] === 0x46) {
                      report([{ url: url, type: 'model', ext: 'glb', inline: abToB64(u8) }]);
                    } else if (u8.length && u8[0] === 0x7b) {
                      // gltf JSON：含 "asset" 字段
                      try { const s = new TextDecoder().decode(u8.subarray(0, 512)); if (/"asset"/.test(s)) report([{ url: url, type: 'model', ext: 'gltf', inline: abToB64(u8) }]); } catch (_) {}
                    }
                  } catch (_) {}
                }).catch(function () {});
              }
            }
          } catch (_) {}
          return resp;
        }).catch(function () {}); // 旁路自捕获，不影响页面
      }
      return p;
    };
  } catch (_) {}

  try {
    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function () {
      const a = arguments;
      const u = a[1] || '';
      if (API_RE.test(u)) {
        this.addEventListener('load', function () {
          try { report(extractDownloadUrls(this.responseText || (this.response || ''))); } catch (_) {}
        });
      }
      // ★通用音频捕获：XHR 拉音频（含无扩展名接口，靠响应 content-type / 签名参数判定）
      try {
        if (window.__hmdao_remember_audio) {
          const xhrAudioExt = /\.(mp3|wav|flac|aac|m4a|ogg|opus|wma|amr|mid|midi)([?#]|$)/i.test(u);
          const xhrAigeiSigned = /aigei\.com$|alicdn\.com$|aliyuncs\.com$|aliyun\.com$|oss-/.test(u) && /[?&](e|token|t|sign|sk|expire|expires|k|fm|tt|x-oss-)/i.test(u);
          if (xhrAudioExt || xhrAigeiSigned) window.__hmdao_remember_audio(u, 'xhr');
        }
      } catch (_) {}
      // ★爱给等音效站 best-effort（同 fetch 段说明，路径白名单 + 签名参数放宽）
      try {
        if (window.__hmdao_remember_audio) {
          let h = '';
          try { h = new URL(u).hostname; } catch (_) {}
          if (/(^|\.)aigei\.com$/i.test(h) || /(^|\.)aigei\.com$|alicdn\.com$|aliyuncs\.com$|aliyun\.com$|oss-/.test(u)) {
            // ★放宽（2026-08-01）：爱给真实音频常托管在 alicdn/OSS 外域 CDN，路径不含 aigei.com。
            // 故把"外域 CDN + 音频签名参数"也纳入 best-effort，覆盖分类页/详情页试听直链。
            const aigeiAudioPath = /\/(play|listen|voice|media|file|get|download|resource|api\/|bgm|effect|sfx|sound|yinxiao|bmg|music|mp3|wav|m4a|wav)(\/|$|[?#])/i;
            // 仅「纯导航页」排除，分类页内试听（含 class + play/签名）不再误杀。
            const aigeiNavOnly = /\/(class|index|list|category|search|tag|rank|topic)\/?$/i;
            const aigeiSigned = /[?&](e|token|t|sign|sk|expire|expires|k|fm|tt|x-oss-)/i.test(u);
            const isPlay = aigeiAudioPath.test(u);
            const isCDN = /alicdn\.com$|aliyuncs\.com$|aliyun\.com$|oss-/.test(u);
            const isSigned = aigeiSigned.test(u);
            const isNavOnly = aigeiNavOnly.test(u) && !isPlay && !isSigned;
            // 主域带播放路径/签名 或 外域 CDN 带签名（试听直链）→ 记
            if ((isPlay && !isNavOnly) || (isSigned && !isNavOnly) || (isCDN && isSigned)) window.__hmdao_remember_audio(u, 'aigei-besteffort');
          }
        }
      } catch (_) {}
      this.addEventListener('load', function () {
        try {
          const ct = (this.getResponseHeader && (this.getResponseHeader('content-type') || '')) || '';
          const ctUrl = this.responseURL || u;
          const ctIsAigei = /aigei\.com$|alicdn\.com$|aliyuncs\.com$|aliyun\.com$|oss-/.test(ctUrl);
          if ((/^audio\//i.test(ct) || (ctIsAigei && /application\/(octet-stream|.*download)|binary\//i.test(ct))) && window.__hmdao_remember_audio) window.__hmdao_remember_audio(ctUrl, 'xhr-ct');
        } catch (_) {}
      });
      // ★根因修复（2026-08-01）：透传全部参数（含第 3 个 async），避免吞掉 async 导致
      // 页面同步 XHR 被静默改成异步，进而设置 responseType/timeout 抛 DOMException。
      return origOpen.apply(this, a);
    };
  } catch (_) {}

  // 「藏在另外的下载链接里」场景：站点 JS 在调完下载 API 后，把签名地址写进
  // <a href> / <area href> / data-* 属性 / download 属性（DOM 静态扫描抓不到，因为扫描时还没填充）。
  // 用 MutationObserver 监听 DOM 变化，把新出现/被改动的模型或压缩包直链也捕获上报。
  try {
    if (typeof MutationObserver !== 'undefined' && typeof document !== 'undefined') {
      const ATTRS = ['href', 'src', 'data-src', 'data-url', 'data-link', 'data-download', 'data-href', 'download'];
      const scanNode = (node) => {
        if (!node || node.nodeType !== 1) return;
        try {
          for (const a of ATTRS) {
            const v = node.getAttribute && node.getAttribute(a);
            if (v && /^https?:/i.test(v) && (MODEL_RE.test(v) || ARCH_RE.test(v))) report([v]);
          }
          if (node.querySelectorAll) {
            node.querySelectorAll('a[href],area[href]').forEach((el) => {
              const h = el.getAttribute('href');
              if (h && /^https?:/i.test(h) && (MODEL_RE.test(h) || ARCH_RE.test(h))) report([h]);
            });
          }
        } catch (_) {}
      };
      const mo = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.addedNodes) { for (const n of m.addedNodes) scanNode(n); }
          if (m.type === 'attributes' && m.target) scanNode(m.target);
        }
      });
      mo.observe(document.documentElement || document, {
        childList: true, subtree: true, attributes: true, attributeFilter: ATTRS,
      });
    }
  } catch (_) {}

  // ★被动 click 兜底（零副作用）：仅观察用户真实点击，绝不主动触发播放/请求。
  // 爱给等站点试听按钮可能不带可预测 URL，而是点击后才由页面 JS 注入签名音频到游离 Audio / <audio>。
  // 本钩子在用户点击「疑似播放按钮」时，扫描该元素及最近容器的音频关联（data-src/data-url/<audio>/data-mp3），
  // 主动 remember，确保「点过试听」的音效一定被采集；同时给页面 400ms 让它的 JS 注入 Audio 后被既有钩子捕获。
  try {
    if (typeof document !== 'undefined' && !window.__hmdao_click_audio_watch) {
      window.__hmdao_click_audio_watch = true;
      const looksPlayLike = (el) => {
        if (!el || el.nodeType !== 1) return false;
        const txt = (el.textContent || '').trim();
        const cls = (typeof el.className === 'string' ? el.className : (el.getAttribute && el.getAttribute('class') || ''));
        const attrs = (el.getAttribute && (el.getAttribute('aria-label') || '')) || '';
        const sig = (cls + ' ' + txt + ' ' + attrs).toLowerCase();
        return /(play|试听|listen|audio|voice|播放|听|sound|music)/i.test(sig) ||
               /data-(play|audio|sound|src|url|mp3)/i.test(el.outerHTML || '');
      };
      const collectFromEl = (el) => {
        if (!el || el.nodeType !== 1) return;
        const tryRem = (u, how) => {
          if (u && /^https?:/i.test(u) && window.__hmdao_remember_audio) window.__hmdao_remember_audio(u, how);
        };
        // 元素自身的音频属性
        ['data-src', 'data-url', 'data-mp3', 'data-audio', 'data-media', 'src'].forEach(a => {
          const v = el.getAttribute && el.getAttribute(a);
          if (v) tryRem(v, 'click-attr');
        });
        // 同容器内的 <audio>
        try {
          const root = el.closest('[class],li,div,tr,article,a') || el.parentElement || el;
          const audios = root.querySelectorAll ? root.querySelectorAll('audio[src],audio source[src]') : [];
          audios.forEach(aud => {
            const s = aud.currentSrc || aud.src || (aud.querySelector && aud.querySelector('source') && aud.querySelector('source').src);
            if (s) tryRem(s, 'click-audio-el');
          });
          // data-* 里可能藏 URL
          if (root.getAttribute) {
            for (const a of root.attributes) {
              if (/src|url|mp3|audio|media|sound/i.test(a.name) && /^https?:/i.test(a.value)) tryRem(a.value, 'click-attr');
            }
          }
        } catch (_) {}
      };
      document.addEventListener('click', (ev) => {
        try {
          let el = ev.target;
          while (el && el.nodeType === 1) {
            if (looksPlayLike(el)) { collectFromEl(el); break; }
            el = el.parentElement;
          }
          // 给页面 JS 注入 Audio 留时间，既有钩子会在 play/src 时自动捕获
        } catch (_) {}
      }, true);
    }
  } catch (_) {}
})();

// ===== 爱给视频多分辨率捕获（MAIN 世界，零副作用） =====
// 爱给视频详情页（aigei.com/video/...）的播放器有画质选择（4K/1080P/720P），
// 切换画质时会改变 <video> 的 src。被动监听这些变化，把不同画质的 URL 存进
// window.__hmdao_captures.aigeiVideos，由 background 扫描时读回，侧栏即可呈现
// 用户已在源页切过的所有分辨率。不主动触发画质切换，不影响页面播放器。
(function () {
  if (typeof window === 'undefined' || window.__hmdao_aigei_video_capture) return;
  window.__hmdao_aigei_video_capture = true;

  const isAigeiVideoPage = () => {
    try {
      return /(^|\.)aigei\.com$/i.test(location.hostname) && /\/video\//.test(location.pathname);
    } catch (_) { return false; }
  };
  if (!isAigeiVideoPage()) return;

  function bag() {
    const c = window.__hmdao_captures = window.__hmdao_captures || {};
    return c.aigeiVideos = c.aigeiVideos || [];
  }
  function normalizeUrl(u) {
    try { return new URL(u, location.href).href; } catch (_) { return u; }
  }
  function rememberVideo(url, qualityHint) {
    try {
      if (!url || typeof url !== 'string') return;
      if (/^(blob:|data:|mediasource:)/i.test(url)) return;
      const u = normalizeUrl(url);
      if (!/^https?:/i.test(u)) return;
      if (!/\.(mp4|webm|m3u8|mov|m4v|mkv|ogv|flv|f4v)(\?[^"'\s}]*)?/i.test(u)) return;
      const list = bag();
      let path = u;
      try { const x = new URL(u); path = x.origin + x.pathname; } catch (_) {}
      const idx = list.findIndex((e) => e.path === path);
      const item = { url: u, path, quality: qualityHint || '', ts: Date.now() };
      if (idx >= 0) list[idx] = item; else list.push(item);
      if (list.length > 50) list.shift();
      // 零副作用：仅在真实发生切换/加载后通知 ISOLATED world 触发后台 rescan，不主动请求
      try { window.postMessage({ __hmdao_type: 'VIDEO_CAPTURED', url: u, path, quality: qualityHint || '' }, location.origin); } catch (_) {}
    } catch (_) {}
  }
  function scanVideoEl(v) {
    if (!v || v.nodeType !== 1) return;
    const src = v.currentSrc || v.src;
    if (src) rememberVideo(src, v.dataset.quality || v.getAttribute('data-quality') || '');
    if (v.querySelectorAll) {
      v.querySelectorAll('source').forEach((s) => {
        const q = s.dataset.quality || s.getAttribute('data-quality') || s.getAttribute('label') || s.getAttribute('title') || '';
        if (s.src) rememberVideo(s.src, q);
      });
    }
  }

  // DOM 监听：已有 video、新增 video、src 属性变化
  try {
    document.querySelectorAll('video').forEach(scanVideoEl);
    if (typeof MutationObserver !== 'undefined') {
      const mo = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.addedNodes) {
            for (const n of m.addedNodes) {
              if (n.nodeType === 1) {
                if (n.tagName === 'VIDEO') scanVideoEl(n);
                if (n.querySelectorAll) n.querySelectorAll('video').forEach(scanVideoEl);
              }
            }
          }
          if (m.type === 'attributes' && m.target && m.target.tagName === 'VIDEO' && m.attributeName === 'src') {
            scanVideoEl(m.target);
          }
        }
      });
      mo.observe(document.documentElement || document, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
    }
  } catch (_) {}

  // 旁路监听 src setter：只记录，不改变原生行为
  try {
    const proto = HTMLMediaElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'src');
    if (desc && desc.set && !window.__hmdao_aigei_src_hooked) {
      window.__hmdao_aigei_src_hooked = true;
      const origSet = desc.set;
      Object.defineProperty(proto, 'src', {
        configurable: true,
        get: desc.get,
        set: function (v) {
          try { if (this.tagName === 'VIDEO') rememberVideo(v, this.dataset.quality || ''); } catch (_) {}
          return origSet.call(this, v);
        }
      });
    }
  } catch (_) {}

  // 兜底轮询：应对 SPA 动态替换 video 不触发 mutation 的情况
  try {
    setInterval(() => { document.querySelectorAll('video').forEach(scanVideoEl); }, 2000);
  } catch (_) {}
})();

// ===== 接口响应体视频直链捕获（全站 MAIN 世界） =====
// ★根因修复（2026-08-01）：原逻辑放在 inject-main.js，但 manifest 仅对 bilibili/youtube 注入
// → 非 YT/B站的站点（LiblibAI / 模型社区 / 云桥网 等）的接口视频直链【从未被捕获】。
// 本文件是全站 MAIN 注入，故把捕获钩子迁移到这里，覆盖所有站点。
// 站点"视频在 XHR/fetch 响应 JSON 里"（如 liblib 搜索接口返回 mp4 直链），
// SPA 异步渲染进 DOM（常仅 hover 时才把 <img> 换成 <video>）→ 静态 DOM 扫描抓不到，
// 必须 patch 网络层，从响应体里扫出 mp4/webm/m3u8 等直链，存进 window.__hmdao_captures.apiVideos，
// 由 background 扫描时经 readAllCapturesMAIN 回读合并（见 scanTab 的 readMainCaptures）。
(function () {
  if (typeof window === 'undefined' || window.__hmdao_api_video_capture) return;
  window.__hmdao_api_video_capture = true;

  const API_VIDEO_RE = /https?:\/\/[^"'\\<>()\s]+\.(mp4|webm|m3u8|mov|m4v|mkv|ogv|flv|f4v)(\?[^\"'\\<>()\s]*)?/gi;

  function scanApiVideoUrls(text) {
    if (!text || typeof text !== 'string') return;
    if (text.length > 2 * 1024 * 1024) return; // 仅扫接口 JSON，跳过超长文本
    if (text.indexOf('{') < 0 && text.indexOf('[') < 0) return; // 非 JSON 不扫
    try {
      const c = (window.__hmdao_captures = window.__hmdao_captures || {});
      const arr = c.apiVideos = c.apiVideos || [];
      let m;
      API_VIDEO_RE.lastIndex = 0;
      while ((m = API_VIDEO_RE.exec(text)) && arr.length < 100) {
        const u = m[0];
        if (arr.indexOf(u) < 0) {
          arr.push(u);
          if (arr.length > 100) arr.shift();
        }
      }
    } catch (_) {}
  }
  window.__hmdaoScanApiVideoUrls = scanApiVideoUrls;

  // 包一层 window.fetch：仅对「JSON 响应」做轻量 text 克隆扫描。
  // 注意：上方 model IIFE 已 patch 过一次 fetch，这里包在它外面再 clone 一次是安全的
  // （clone 不改变页面侧消费的响应，互不影响）。
  const origFetch = window.fetch;
  try {
    window.fetch = function () {
      const url = (typeof arguments[0] === 'string' ? arguments[0] : (arguments[0] && arguments[0].url)) || '';
      const p = origFetch.apply(this, arguments);
      if (p && typeof p.then === 'function') {
        p.then(function (resp) {
          try {
            const ct = (resp && resp.headers && resp.headers.get) ? (resp.headers.get('content-type') || '') : '';
            if (/json/i.test(ct) && resp.clone) {
              resp.clone().text().then(function (t) { try { scanApiVideoUrls(t); } catch (_) {} }).catch(function () {});
            }
          } catch (_) {}
          return resp;
        }).catch(function () {});
      }
      return p;
    };
  } catch (_) {}

  try {
    const oOpen = XMLHttpRequest.prototype.open;
    const oSend = XMLHttpRequest.prototype.send;
    // ★根因修复（2026-08-01）：原 open 重写只传 (m, u) 两个参数，吞掉了第 3 个 async 参数。
    // B站等站点用 open('GET', url, false) 发起【同步】XHR，被静默改成异步后，
    // 页面随后设置 responseType/timeout 会触发「无法设置 responseType」DOMException，干扰网站正常运行。
    // 修复：透传全部参数（method, url, async, user, password），保持页面原生语义不变。
    XMLHttpRequest.prototype.open = function () { return oOpen.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function (b) {
      const self = this;
      self.addEventListener('load', function () {
        try {
          const ct = (self.getResponseHeader && self.getResponseHeader('content-type')) || '';
          if (/json/i.test(ct) && typeof self.responseText === 'string') scanApiVideoUrls(self.responseText);
        } catch (_) {}
      });
      return oSend.call(this, b);
    };
  } catch (_) {}
})();

// ===== 通用音频播放捕获（全站 MAIN 世界） =====
// ★根因（爱给实测）：预览播放器是【游离 new Audio()】——不在 DOM、初始无 src，
// 点击试听时才把限时签名 mp3 注入其中一个播放：
//   1) DOM 扫描 querySelectorAll('audio') 永远看不到（元素没挂进 DOM）；
//   2) 网络层 webRequest 在「SW 冷启动竞态 / memory cache 命中（根本不发事件）」时会漏；
//   3) inject-main 只注入 B站/YouTube，通用站点无播放钩子。
// 修复：钩 Audio 构造 / HTMLMediaElement.play / src setter（+上方 fetch/XHR 的 content-type 旁路），
// 把播放过的音频 URL 存 window.__hmdao_captures.audioPlays（页面全局，抗 SW 重启、抗缓存命中），
// 由 background 扫描时以 world:'MAIN' 的 readAllCapturesMAIN 读回合并。
(function () {
  if (typeof window === 'undefined' || window.__hmdao_audio_capture) return;
  if (__hmdao_isBiliPlayPage()) return; // B站播放页熔断：不 patch，兼容原生播放器
  if (__hmdao_isDouyinPlayPage()) return; // 抖音/TikTok 播放页熔断：不 patch，兼容原生播放器
  window.__hmdao_audio_capture = true;

  function bag() {
    const c = window.__hmdao_captures = window.__hmdao_captures || {};
    return (c.audioPlays = c.audioPlays || []);
  }
  // 拒绝明显不是音频的 URL（如图片/视频扩展名、追踪像素等）。
  // 部分站点会错误地把封面图/jpg 传进 soundManager.createSound，不过滤会让音频模块混入图片。
  function isObviousNonAudioUrl(url) {
    try {
      const path = new URL(url).pathname.toLowerCase();
      if (/\.(jpg|jpeg|png|gif|webp|bmp|svg|ico|avif|apng|tif|tiff)(\?|#|$)/.test(path)) return true;
      if (/\.(mp4|webm|mov|m4v|mkv|ogv|m3u8|mpd|flv|avi|wmv|ts|3gp|f4v)(\?|#|$)/.test(path)) return true;
      if (/\.(json|xml|html?|css|js|pdf|docx?|zip|rar|7z|gz|tar)(\?|#|$)/.test(path)) return true;
      if (/(^|\/)(1x1|spacer|pixel|beacon|track|collect|analytics)(\.[^/]*)?$/i.test(path)) return true;
    } catch (_) {}
    return false;
  }

  function remember(url, how) {
    try {
      if (!url || typeof url !== 'string') return;
      if (/^(blob:|data:|mediasource:)/i.test(url)) return; // blob/data 跨上下文不可用
      try { url = new URL(url, location.href).href; } catch (_) { return; }
      if (!/^https?:/i.test(url)) return;
      if (isObviousNonAudioUrl(url)) return; // 2026-08-02 防止图片/视频混入音频模块
      const list = bag();
      // 按 origin+pathname 去重：爱给等站的签名参数（?e=&token=）会刷新，
      // 同 pathname 视为同一音频，永远保留【最新】签名 URL（旧签名已过期无用）。
      let path = url;
      try { const x = new URL(url); path = x.origin + x.pathname; } catch (_) {}
      const item = { url, path, how, ts: Date.now() };
      const idx = list.findIndex((e) => e.path === path);
      if (idx >= 0) list[idx] = item; else list.push(item);
      if (list.length > 200) list.shift();
      // ★零副作用：用户真点试听、音频被捕获后，通知 ISOLATED world 的 content script
      // （scanPage）去触发后台 rescan，让侧栏实时出现音效（不主动点击/播放，纯被动）。
      // MAIN 世界变量 ISOLATED 读不到，故用 window.postMessage 跨 world 通信。2026-08-01。
      try { window.postMessage({ __hmdao_type: 'AUDIO_CAPTURED', url, path }, location.origin); } catch (_) {}
    } catch (_) {}
  }
  window.__hmdao_remember_audio = remember; // 供上方 fetch/XHR 钩子复用

  // ===== 旁路监听（非破坏性，不改变原生 API 行为，不影响页面播放器）=====

  // ★ 关键设计原则：爱给等站点使用 SoundManager 2 库，内部 new Audio() 创建音频元素。
  // 不能 patch window.Audio / HTMLMediaElement.prototype.src / play / setAttribute ——
  // 这些钩子会改变原生行为，导致 SoundManager 播放链路异常（试听无声音）。
  // 改为纯旁路监听：只记录 URL，不拦截/改变原生 API 的返回值或行为。

  // 1) soundManager.createSound({url})：爱给 AudioPlayerManager.audioUrlRequest
  //    最终调 soundManager.createSound({id, url}) 加载真实 mp3。这是最精准的入口，
  //    零副作用——只读 opts.url，不改 createSound 的返回值和内部行为。
  try {
    const SM = window.soundManager;
    if (SM && typeof SM.createSound === 'function' && !window.__hmdao_sm_hooked) {
      window.__hmdao_sm_hooked = true;
      const origCreateSound = SM.createSound.bind(SM);
      SM.createSound = function (opts) {
        try {
          if (opts && typeof opts.url === 'string') {
            remember(opts.url, 'soundmanager-createSound');
          }
        } catch (_) {}
        return origCreateSound(opts);
      };
    }
  } catch (_) {}

  // 2) fetch/XHR 旁路（已在文件前面的拦截器中）：URL 带音频扩展名或响应 content-type: audio/*
  //    走 remember(url, 'fetch'/'xhr')，不改原生 fetch/XHR 行为，仅旁路记录。
  //    详见本文件上方 fetch/XHR 拦截器（__hmdao_remember_audio 回调）。

  // 3) HTMLMediaElement.prototype.play 旁路：仅用于调试记录（可选，不影响行为）。
  //    当前不启用，避免任何对原生 API 的修改。

})();
