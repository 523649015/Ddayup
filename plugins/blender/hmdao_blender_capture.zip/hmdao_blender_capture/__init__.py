bl_info = {
    "name": "HMDao Blender Capture",
    "author": "HMDao",
    "version": (1, 1, 2),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > HMDao",
    "description": "Expose Blender camera preview and capture to HMDao canvas.",
    "category": "Render",
}

import base64
import hashlib
import json
import os
import queue
import socket
import struct
import tempfile
import threading
import time
import traceback

import bpy


HOST = "127.0.0.1"
PORT = 8766
PLUGIN_VERSION = "1.1.2"
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
COMMAND_QUEUE = queue.Queue()
SERVER = None
LOG_PATH = os.path.join(tempfile.gettempdir(), "hmdao_blender_capture.log")


def _log(message):
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as handle:
            handle.write(line)
    except OSError:
        pass


def _ws_accept_key(key):
    digest = hashlib.sha1((key + WS_GUID).encode("utf-8")).digest()
    return base64.b64encode(digest).decode("ascii")


def _encode_frame(text):
    payload = text.encode("utf-8")
    header = bytearray([0x81])
    length = len(payload)
    if length < 126:
        header.append(length)
    elif length < 65536:
        header.extend([126, (length >> 8) & 0xFF, length & 0xFF])
    else:
        header.append(127)
        header.extend(struct.pack(">Q", length))
    return bytes(header) + payload


def _camera_objects():
    return [obj for obj in bpy.context.scene.objects if obj.type == "CAMERA"]


def _camera_list():
    active = bpy.context.scene.camera
    return [
        {
            "name": camera.name,
            "label": camera.name,
            "active": bool(active and active.name == camera.name),
            "engine": "blender",
        }
        for camera in _camera_objects()
    ]


def _select_camera(name):
    cameras = _camera_objects()
    if name:
        for camera in cameras:
            if camera.name == name:
                bpy.context.scene.camera = camera
                return camera
    if bpy.context.scene.camera:
        return bpy.context.scene.camera
    if cameras:
        bpy.context.scene.camera = cameras[0]
        return cameras[0]
    return None


def _timeline_payload():
    scene = bpy.context.scene
    fps = scene.render.fps / max(1, scene.render.fps_base)
    return {
        "type": "animation_range",
        "start_frame": int(scene.frame_start),
        "end_frame": int(scene.frame_end),
        "current_frame": int(scene.frame_current),
        "fps": round(fps),
    }


def _render_camera_data_url(camera_name, width, height, quality=90, file_format="JPEG"):
    camera = _select_camera(camera_name)
    if camera is None:
        raise RuntimeError("当前 Blender 场景中没有可用摄像机。")

    scene = bpy.context.scene
    old_camera = scene.camera
    old_x = scene.render.resolution_x
    old_y = scene.render.resolution_y
    old_percent = scene.render.resolution_percentage
    old_format = scene.render.image_settings.file_format
    old_quality = scene.render.image_settings.quality
    old_path = scene.render.filepath

    suffix = ".jpg" if file_format == "JPEG" else ".png"
    fd, filepath = tempfile.mkstemp(prefix="hmdao_blender_", suffix=suffix)
    os.close(fd)

    try:
        scene.camera = camera
        scene.render.resolution_x = int(width)
        scene.render.resolution_y = int(height)
        scene.render.resolution_percentage = 100
        scene.render.image_settings.file_format = file_format
        scene.render.image_settings.quality = int(max(1, min(100, quality)))
        scene.render.filepath = filepath
        try:
            bpy.ops.render.opengl(write_still=True, view_context=False)
        except Exception:
            bpy.ops.render.render(write_still=True)
        with open(filepath, "rb") as handle:
            encoded = base64.b64encode(handle.read()).decode("ascii")
        mime = "image/jpeg" if file_format == "JPEG" else "image/png"
        return f"data:{mime};base64,{encoded}"
    finally:
        scene.camera = old_camera
        scene.render.resolution_x = old_x
        scene.render.resolution_y = old_y
        scene.render.resolution_percentage = old_percent
        scene.render.image_settings.file_format = old_format
        scene.render.image_settings.quality = old_quality
        scene.render.filepath = old_path
        try:
            os.remove(filepath)
        except OSError:
            pass


class HMDaoClient:
    def __init__(self, sock, address, server):
        self.sock = sock
        self.address = address
        self.server = server
        self.closed = False
        self.preview = None
        self.lock = threading.Lock()
        self.buffer = bytearray()

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def close(self):
        self.closed = True
        try:
            self.sock.close()
        except OSError:
            pass
        self.server.remove_client(self)

    def send(self, payload):
        if self.closed:
            return
        try:
            text = json.dumps(payload, ensure_ascii=False)
            with self.lock:
                self.sock.sendall(_encode_frame(text))
        except OSError:
            self.close()

    def _handshake(self):
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("empty handshake")
            data += chunk
            if len(data) > 65536:
                raise ConnectionError("handshake too large")
        header_end = data.index(b"\r\n\r\n")
        self.buffer.extend(data[header_end + 4:])
        header = data.decode("utf-8", "ignore")
        request_line = header.splitlines()[0] if header.splitlines() else ""
        if "upgrade: websocket" not in header.lower():
            body = json.dumps({"success": True, "service": "hmdao-blender-capture", "version": PLUGIN_VERSION}, ensure_ascii=False)
            response = (
                "HTTP/1.1 200 OK\r\n"
                "Content-Type: application/json; charset=utf-8\r\n"
                f"Content-Length: {len(body.encode('utf-8'))}\r\n"
                "Connection: close\r\n\r\n"
                f"{body}"
            )
            self.sock.sendall(response.encode("utf-8"))
            raise ConnectionError("non-websocket health request")
        key = ""
        for line in header.splitlines():
            if line.lower().startswith("sec-websocket-key:"):
                key = line.split(":", 1)[1].strip()
                break
        if not key:
            raise ConnectionError("missing websocket key")
        response = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {_ws_accept_key(key)}\r\n\r\n"
        )
        self.sock.sendall(response.encode("ascii"))
        _log(f"WebSocket handshake ok from {self.address}: {request_line}")

    def _recv_frame_text(self):
        while len(self.buffer) < 2:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("socket closed")
            self.buffer.extend(chunk)
        first = self.buffer[0]
        second = self.buffer[1]
        opcode = first & 0x0F
        masked = bool(second & 0x80)
        length = second & 0x7F
        offset = 2
        if length == 126:
            while len(self.buffer) < 4:
                self.buffer.extend(self.sock.recv(4096))
            length = struct.unpack(">H", bytes(self.buffer[2:4]))[0]
            offset = 4
        elif length == 127:
            while len(self.buffer) < 10:
                self.buffer.extend(self.sock.recv(4096))
            length = struct.unpack(">Q", bytes(self.buffer[2:10]))[0]
            offset = 10
        mask = b""
        if masked:
            while len(self.buffer) < offset + 4:
                self.buffer.extend(self.sock.recv(4096))
            mask = bytes(self.buffer[offset:offset + 4])
            offset += 4
        while len(self.buffer) < offset + length:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("socket closed")
            self.buffer.extend(chunk)
        payload = bytearray(self.buffer[offset:offset + length])
        del self.buffer[:offset + length]
        if masked:
            for index in range(length):
                payload[index] ^= mask[index % 4]
        if opcode == 0x8:
            raise ConnectionError("client closed")
        if opcode != 0x1:
            return None
        return payload.decode("utf-8")

    def _run(self):
        try:
            self._handshake()
            self.server.add_client(self)
            while not self.closed:
                text = self._recv_frame_text()
                if not text:
                    continue
                try:
                    payload = json.loads(text)
                except ValueError:
                    self.send({"type": "error", "message": "HMDao Blender 插件收到无法解析的消息。"})
                    continue
                COMMAND_QUEUE.put((self, payload))
        except Exception as exc:
            _log(f"Client {self.address} closed: {exc}\n{traceback.format_exc()}")
            self.close()


class HMDaoCaptureServer:
    def __init__(self):
        self.sock = None
        self.thread = None
        self.running = False
        self.clients = set()

    def start(self):
        if self.running:
            return
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((HOST, PORT))
        self.sock.listen(8)
        self.running = True
        _log(f"HMDao Blender Capture {PLUGIN_VERSION} listening on {HOST}:{PORT}")
        self.thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.thread.start()
        if not bpy.app.timers.is_registered(self._timer):
            bpy.app.timers.register(self._timer, persistent=True)

    def stop(self):
        self.running = False
        for client in list(self.clients):
            client.close()
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None

    def add_client(self, client):
        self.clients.add(client)

    def remove_client(self, client):
        self.clients.discard(client)

    def _accept_loop(self):
        while self.running and self.sock:
            try:
                client_sock, address = self.sock.accept()
                _log(f"Accepted client {address}")
                HMDaoClient(client_sock, address, self).start()
            except OSError as exc:
                _log(f"Accept loop stopped: {exc}")
                break

    def _timer(self):
        if not self.running:
            return None
        self._drain_commands()
        self._push_preview_frames()
        return 0.03

    def _drain_commands(self):
        while True:
            try:
                client, payload = COMMAND_QUEUE.get_nowait()
            except queue.Empty:
                break
            self._handle(client, payload)

    def _push_preview_frames(self):
        now = time.monotonic()
        for client in list(self.clients):
            preview = client.preview
            if not preview:
                continue
            fps = max(1, min(12, int(preview.get("fps", 8))))
            if now - preview.get("last", 0) < 1 / fps:
                continue
            preview["last"] = now
            self._send_frame(client, preview)

    def _send_cameras(self, client):
        camera = _select_camera(None)
        client.send({
            "type": "camera_list",
            "camera_list": _camera_list(),
            "selected_camera": camera.name if camera else "",
        })

    def _send_timeline(self, client):
        client.send(_timeline_payload())

    def _send_frame(self, client, options):
        try:
            width = int(options.get("w") or options.get("width") or 1280)
            height = int(options.get("h") or options.get("height") or 720)
            camera_name = str(options.get("camera_name") or "")
            url = _render_camera_data_url(camera_name, width, height, quality=80, file_format="JPEG")
            camera = bpy.context.scene.camera
            client.send({
                "type": "frame",
                "url": url,
                "width": width,
                "height": height,
                "camera_name": camera.name if camera else camera_name,
                "source": "plugin",
                "latency_ms": 0,
            })
        except Exception as exc:
            client.send({"type": "error", "message": f"Blender 摄像机预览失败：{exc}"})

    def _handle(self, client, payload):
        message_type = str(payload.get("type", ""))
        if message_type == "connect":
            camera = _select_camera(payload.get("camera_name"))
            client.send({
                "type": "connected",
                "engine": "blender",
                "mode": "real",
                "message": f"HMDao Blender Capture {PLUGIN_VERSION} 插件已连接，预览来自当前 Blender 摄像机。",
            })
            self._send_cameras(client)
            self._send_timeline(client)
            if camera:
                client.preview = {
                    "camera_name": camera.name,
                    "w": payload.get("w", 1280),
                    "h": payload.get("h", 720),
                    "fps": payload.get("fps", 8),
                    "last": 0,
                }
            return
        if message_type == "query_camera":
            self._send_cameras(client)
            return
        if message_type in {"query_animation_range", "timeline", "scene_info"}:
            self._send_timeline(client)
            return
        if message_type == "set_camera":
            _select_camera(payload.get("camera_name"))
            self._send_cameras(client)
            self._send_timeline(client)
            return
        if message_type == "start_preview":
            _select_camera(payload.get("camera_name"))
            client.preview = dict(payload)
            client.preview["last"] = 0
            self._send_frame(client, client.preview)
            return
        if message_type == "stop_preview":
            client.preview = None
            return
        if message_type == "capture_by_camera":
            self._capture(client, payload)
            return
        if message_type == "start_recording":
            client.preview = dict(payload)
            client.preview["last"] = 0
            client.send({
                "type": "recording_started",
                "camera_name": payload.get("camera_name") or (bpy.context.scene.camera.name if bpy.context.scene.camera else ""),
                "start_frame": payload.get("start_frame"),
                "end_frame": payload.get("end_frame"),
                "fps": payload.get("fps"),
                "source": "plugin",
            })
            return
        if message_type == "stop_recording":
            client.send({
                "type": "recording_stopped",
                "camera_name": payload.get("camera_name") or (bpy.context.scene.camera.name if bpy.context.scene.camera else ""),
                "source": "plugin",
            })

    def _capture(self, client, payload):
        try:
            width = int(payload.get("w") or payload.get("width") or 1920)
            height = int(payload.get("h") or payload.get("height") or 1080)
            camera_name = str(payload.get("camera_name") or "")
            url = _render_camera_data_url(camera_name, width, height, quality=int(payload.get("quality", 95)), file_format="JPEG")
            camera = bpy.context.scene.camera
            client.send({
                "type": "capture_done",
                "url": url,
                "width": width,
                "height": height,
                "camera_name": camera.name if camera else camera_name,
                "size_bytes": len(url),
                "source": "plugin",
            })
        except Exception as exc:
            client.send({"type": "error", "message": f"Blender 截图失败：{exc}"})


class HMDAO_OT_start_capture(bpy.types.Operator):
    bl_idname = "hmdao.start_capture"
    bl_label = "启动 HMDao 捕捉服务"

    def execute(self, context):
        global SERVER
        if SERVER is None:
            SERVER = HMDaoCaptureServer()
        try:
            SERVER.start()
            context.scene.hmdao_capture_status = f"已启动：{HOST}:{PORT} / v{PLUGIN_VERSION}"
            return {"FINISHED"}
        except Exception as exc:
            context.scene.hmdao_capture_status = f"启动失败：{exc}"
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class HMDAO_OT_stop_capture(bpy.types.Operator):
    bl_idname = "hmdao.stop_capture"
    bl_label = "停止 HMDao 捕捉服务"

    def execute(self, context):
        global SERVER
        if SERVER:
            SERVER.stop()
        context.scene.hmdao_capture_status = "已停止"
        return {"FINISHED"}


class HMDAO_PT_capture_panel(bpy.types.Panel):
    bl_label = "HMDao Blender Capture"
    bl_idname = "HMDAO_PT_capture_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HMDao"

    def draw(self, context):
        layout = self.layout
        layout.label(text="HMDao Blender 插件")
        layout.label(text="用途：向 HMDao 画布推送真实摄像机预览")
        layout.operator("hmdao.start_capture", icon="PLAY")
        layout.operator("hmdao.stop_capture", icon="PAUSE")
        layout.label(text=getattr(context.scene, "hmdao_capture_status", "未启动"))
        layout.label(text=f"监听端口：{PORT}")
        layout.label(text=f"协议版本：{PLUGIN_VERSION}")
        layout.label(text=f"日志：{LOG_PATH}")


CLASSES = (
    HMDAO_OT_start_capture,
    HMDAO_OT_stop_capture,
    HMDAO_PT_capture_panel,
)


def register():
    if not hasattr(bpy.types.Scene, "hmdao_capture_status"):
        bpy.types.Scene.hmdao_capture_status = bpy.props.StringProperty(default="未启动")
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass


def unregister():
    global SERVER
    if SERVER:
        SERVER.stop()
        SERVER = None
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    if hasattr(bpy.types.Scene, "hmdao_capture_status"):
        del bpy.types.Scene.hmdao_capture_status
